"""
Blender operators for retargeting workflow and URDF import.

Provides operators for mapping generation, retargeting initialization,
pose calibration, and URDF file import.
"""

import bpy
import os
import mathutils
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper, ExportHelper
from bpy_extras.anim_utils import action_get_channelbag_for_slot
from .urdf import parse_urdf
from .armature import create_urdf_armature, bind_meshes
from .retargeting import get_lowest_z_world, apply_custom_default_pose_to_urdf
from .mapping_io import (
    export_mapping_to_json,
    import_mapping_from_json,
    count_non_quaternion_bones,
    get_preset_library_dir,
    ensure_preset_library_dir,
    sanitize_preset_filename,
)


class OT_GenerateMappingList(Operator):
    """Generate initial BVH-to-URDF bone mapping list from BVH rig."""

    bl_idname = "object.generate_mapping_list"
    bl_label = "Generate Mapping List"
    bl_description = "Generates BVH bone list from selected BVH rig"

    def execute(self, context):
        """Create a mapping entry for each BVH bone."""
        scene = context.scene
        settings = scene.bvh_mapping_settings
        bvh_rig = scene.bvh_rig_object

        if not bvh_rig:
            return {"CANCELLED"}

        # Clear existing mappings
        settings.mappings.clear()

        # Create mapping for each BVH bone
        for ub in [pb.name for pb in bvh_rig.pose.bones]:
            item = settings.mappings.add()
            item.bvh_bone_name = ub

        settings.active_mapping_index = 0
        settings.active_urdf_index = 0
        return {"FINISHED"}


class OT_ApplyBVHMapping(Operator):
    """Reset URDF rig and enable live retargeting with optional smoothing."""

    bl_idname = "object.apply_bvh_mapping"
    bl_label = "Apply Mapping"
    bl_description = "Resets rig to neutral pose at frame 0 and starts live retargeting"

    def _validate_required_fields(self, settings, bvh_obj: bpy.types.Object) -> bool:
        """Validate mandatory fields before enabling live retargeting."""
        missing_fields = []

        if not settings.foot_l_name:
            missing_fields.append("Foot Configuration -> Left Foot")
        if not settings.foot_r_name:
            missing_fields.append("Foot Configuration -> Right Foot")

        if missing_fields:
            self.report(
                {"WARNING"},
                "Apply Mapping cancelled: required fields are missing: "
                + ", ".join(missing_fields),
            )
            return False

        invalid_bones = []
        if bvh_obj.pose.bones.get(settings.foot_l_name) is None:
            invalid_bones.append(
                f"Left Foot '{settings.foot_l_name}' was not found in the BVH rig"
            )
        if bvh_obj.pose.bones.get(settings.foot_r_name) is None:
            invalid_bones.append(
                f"Right Foot '{settings.foot_r_name}' was not found in the BVH rig"
            )

        if invalid_bones:
            self.report(
                {"WARNING"},
                "Apply Mapping cancelled: " + "; ".join(invalid_bones),
            )
            return False

        if settings.foot_l_name == settings.foot_r_name:
            self.report(
                {"WARNING"},
                "Apply Mapping cancelled: Left Foot and Right Foot must be different bones.",
            )
            return False

        return True

    def check_bvh_rotation_mode(self, bvh_obj: bpy.types.Object) -> bool:
        """
        Check if all BVH bones use QUATERNION rotation mode.

        Args:
            bvh_obj: The BVH armature object.

        Returns:
            True if all pose bones use quaternion rotation.
        """
        if bvh_obj.type != "ARMATURE":
            return False

        for pbone in bvh_obj.pose.bones:
            if pbone.rotation_mode != "QUATERNION":
                return False
        return True

    def apply_zero_lag_smoothing(
        self, context, bvh_obj: bpy.types.Object, smoothing_factor: float
    ) -> bpy.types.Object:
        """
        Create a copy of BVH object and apply Zero-Lag F-Curve smoothing.

        Performs bidirectional filtering (forward + backward pass) on quaternion
        rotations and position vectors to reduce noise while preserving motion.

        Args:
            context: The Blender context.
            bvh_obj: The original BVH armature.
            smoothing_factor: Smoothing strength (0.0=no smoothing, 1.0=max).

        Returns:
            The new smoothed BVH armature object.
        """
        # Remove existing smoothed copy if present
        smoothed_name = f"{bvh_obj.name}_smoothed"
        if smoothed_name in bpy.data.objects:
            bvh_obj.hide_viewport = False
            context.view_layer.objects.active = bvh_obj
            bpy.data.objects.remove(bpy.data.objects[smoothed_name], do_unlink=True)

        # Create a duplicate armature with animation data
        new_obj = bvh_obj.copy()
        new_obj.data = bvh_obj.data.copy()
        new_obj.name = smoothed_name
        if bvh_obj.animation_data and bvh_obj.animation_data.action:
            new_obj.animation_data.action = bvh_obj.animation_data.action.copy()

        context.collection.objects.link(new_obj)

        # Hide original and activate smoothed copy
        bvh_obj.hide_viewport = True
        context.view_layer.objects.active = new_obj

        # Ensure quaternion mode
        bpy.ops.object.mode_set(mode="POSE")
        for pbone in new_obj.pose.bones:
            pbone.rotation_mode = "QUATERNION"
        bpy.ops.object.mode_set(mode="OBJECT")

        # Get animation data
        action = new_obj.animation_data.action
        if not action:
            return new_obj

        slot = new_obj.animation_data.action_slot
        channelbag = action_get_channelbag_for_slot(action, slot)
        if not channelbag:
            return new_obj

        # Group F-Curves by data path
        curves_by_group = {}
        for fc in channelbag.fcurves:
            key = fc.data_path
            if key not in curves_by_group:
                curves_by_group[key] = []
            curves_by_group[key].append(fc)

        # Apply Zero-Lag smoothing to each group
        alpha = 1.0 - smoothing_factor
        for path, curves in curves_by_group.items():
            curves.sort(key=lambda x: x.array_index)
            num_keys = len(curves[0].keyframe_points)
            if num_keys < 2:
                continue

            is_quat = "rotation_quaternion" in path
            is_loc = "location" in path

            # Only process quaternions and locations
            if not (is_quat or is_loc):
                continue

            # Load keyframe data
            all_data = []
            for fc in curves:
                coords = [0.0] * (num_keys * 2)
                fc.keyframe_points.foreach_get("co", coords)
                all_data.append(coords)

            # Convert to mathutils types
            points = []
            for i in range(num_keys):
                idx = i * 2 + 1
                if is_quat and len(curves) == 4:
                    points.append(
                        mathutils.Quaternion(
                            (
                                all_data[0][idx],
                                all_data[1][idx],
                                all_data[2][idx],
                                all_data[3][idx],
                            )
                        )
                    )
                else:
                    points.append(
                        mathutils.Vector(
                            (all_data[0][idx], all_data[1][idx], all_data[2][idx])
                        )
                    )

            # Zero-Lag smoothing: forward and backward passes
            smoothed = [p.copy() for p in points]

            # Forward pass
            for i in range(1, num_keys):
                if is_quat:
                    smoothed[i] = smoothed[i - 1].slerp(points[i], alpha)
                else:
                    smoothed[i] = smoothed[i - 1].lerp(points[i], alpha)

            # Backward pass (Zero-Lag)
            for i in range(num_keys - 2, -1, -1):
                if is_quat:
                    smoothed[i] = smoothed[i + 1].slerp(smoothed[i], alpha)
                else:
                    smoothed[i] = smoothed[i + 1].lerp(smoothed[i], alpha)

            # Write back smoothed values
            for i, fc in enumerate(curves):
                for k in range(num_keys):
                    all_data[i][k * 2 + 1] = smoothed[k][i]
                fc.keyframe_points.foreach_set("co", all_data[i])
                fc.update()

        return new_obj

    def execute(self, context):
        """Reset and initialize retargeting."""
        scene = context.scene
        settings = scene.bvh_mapping_settings
        bvh_obj = scene.bvh_rig_object
        urdf_obj = scene.urdf_rig_object

        if not urdf_obj or not bvh_obj:
            self.report({"ERROR"}, "URDF and BVH rigs must be selected!")
            return {"CANCELLED"}

        if not self._validate_required_fields(settings, bvh_obj):
            return {"CANCELLED"}

        # Disable retargeting during setup
        scene.bvh_mapping_settings.live_retarget = False
        scene.frame_set(0)

        # Clear only per-frame transient state keys (not calibration keys)
        for _k in (
            "_persistent_foot_correction",
            "_persistent_foot_rot_correction",
            "_active_anchor_name",
            "_anchor_world_pos_xy",
            "_anchor_world_yaw",
            "_anchor_bvh_yaw",
            "_foot_positions",
            "_bvh_smooth_cache",
            "_kinematic_target_cache",
            "_ik_custom_default_ref_cache",
        ):
            if _k in scene:
                del scene[_k]

        # Reset URDF bones to neutral pose
        for pb in urdf_obj.pose.bones:
            pb.rotation_mode = "QUATERNION"

            l_min = pb.get("limit_lower", -3.14)
            l_max = pb.get("limit_upper", 3.14)
            neutral = max(min(0.0, l_max), l_min)

            pb.rotation_quaternion = mathutils.Quaternion((0, 1, 0), neutral)

            # Clear per-frame caches (not joint limits or joint type which are static)
            for key in (
                "offset",
                "_joint_angle",
                "_last_urdf_angle",
                "_ik_last_angle",
                "is_velocity_limited",
            ):
                if key in pb:
                    del pb[key]

        # Reinitialize global smoothing cache
        scene["_bvh_smooth_cache"] = {}

        # Apply zero-lag smoothing if enabled
        if settings.bvh_smoothing > 0.0:
            if not self.check_bvh_rotation_mode(bvh_obj):
                self.report(
                    {"ERROR"},
                    "Smoothing requires BVH to be imported with Quaternion rotations!",
                )
                return {"CANCELLED"}

            self.report(
                {"INFO"},
                f"Zero-Lag Smoothing BVH Animation (Factor: {settings.bvh_smoothing})...",
            )
            scene.smoothed_bvh_rig_object = self.apply_zero_lag_smoothing(
                context, bvh_obj, settings.bvh_smoothing
            )
        else:
            scene.smoothed_bvh_rig_object = bvh_obj

        # Ensure retargeting starts from the same pose definition used by export
        # to avoid mismatched IK references when custom defaults are enabled.
        apply_custom_default_pose_to_urdf(urdf_obj, settings)

        # Initialize export frame range defaults (only in operator context)
        try:
            if (
                getattr(settings, "export_from_frame", 0) == 0
                and getattr(settings, "export_to_frame", 0) == 0
                and bvh_obj is not None
            ):
                settings.export_from_frame = scene.frame_start
                settings.export_to_frame = scene.frame_end

        except Exception:
            # Defensive: if properties are not present or writing fails, ignore
            pass

        # Calibrate reference poses (sets ref_root_pos, ref_root_rot, bvh_floor_offset, urdf_height_offset)
        bpy.ops.object.calibrate_rest_pose()

        # Enable retargeting
        scene.bvh_mapping_settings.live_retarget = True

        # Burn in frame 0
        for _ in range(100):
            scene.frame_set(0)
            context.view_layer.update()

        # Calculate foot height offset from current URDF foot position
        # Find foot bone names from mappings
        urdf_foot_names = []
        for item in settings.mappings:
            if item.bvh_bone_name in [settings.foot_l_name, settings.foot_r_name]:
                urdf_foot_names.extend([b.urdf_bone_name for b in item.urdf_bones])

        # Compute minimum Z of all foot bones
        min_foot_z = float("inf")
        if urdf_foot_names:
            bpy.context.view_layer.update()
            for u_f_name in urdf_foot_names:
                u_foot = urdf_obj.pose.bones.get(u_f_name)
                if u_foot:
                    z = (urdf_obj.matrix_world @ u_foot.matrix).to_translation().z
                    if z < min_foot_z:
                        min_foot_z = z

        # Set foot height offset, with fallback to 0 if feet are not found
        if min_foot_z == float("inf"):
            min_foot_z = 0.0
            self.report(
                {"WARNING"}, "No foot bones found; using foot height offset 0.0"
            )

        scene["urdf_foot_height_offset"] = min_foot_z

        self.report({"INFO"}, "Rig reset to frame 0. Retargeting active.")
        return {"FINISHED"}


class OT_CalibrateRestPose(Operator):
    """Calibrate mapping offsets based on current BVH pose."""

    bl_idname = "object.calibrate_rest_pose"
    bl_label = "Calibrate Rest Pose"
    bl_description = "Saves the current BVH rotation as the neutral reference."

    def execute(self, context):
        """Store current poses as reference."""
        scene = context.scene
        settings = context.scene.bvh_mapping_settings
        bvh = context.scene.smoothed_bvh_rig_object
        urdf = context.scene.urdf_rig_object

        if not bvh or not urdf:
            self.report({"ERROR"}, "BVH and URDF rigs required!")
            return {"CANCELLED"}

        # Store root pose
        bvh_root_mat = bvh.matrix_world @ bvh.pose.bones[0].matrix
        scene["ref_root_pos"] = bvh_root_mat.to_translation().copy()
        scene["ref_root_rot"] = bvh_root_mat.to_quaternion().copy()

        # Store reference rotation for each mapping
        count = 0
        for item in settings.mappings:
            bvh_bone = bvh.pose.bones.get(item.bvh_bone_name)
            if bvh_bone:
                item.ref_rot = bvh_bone.matrix_basis.to_quaternion()
                count += 1

        # Calculate BVH and URDF floor offsets (always recalculate, don't check if None)
        if (
            settings.foot_l_name in bvh.pose.bones
            and settings.foot_r_name in bvh.pose.bones
        ):
            lowest_bvh_z = min(
                (bvh.matrix_world @ bvh.pose.bones.get(settings.foot_l_name).matrix)
                .to_translation()
                .z,
                (bvh.matrix_world @ bvh.pose.bones.get(settings.foot_r_name).matrix)
                .to_translation()
                .z,
            )
            if scene.get("bvh_floor_offset", None) is None:
                scene["bvh_floor_offset"] = lowest_bvh_z
            if scene.get("urdf_height_offset", None) is None:
                scene["urdf_height_offset"] = abs(get_lowest_z_world(urdf))
        else:
            # Fallback without foot anchors so operator never crashes on missing setup.
            if scene.get("bvh_floor_offset", None) is None:
                lowest_bvh_z = min(
                    (bvh.matrix_world @ pb.matrix).to_translation().z
                    for pb in bvh.pose.bones
                )
                scene["bvh_floor_offset"] = lowest_bvh_z
            if scene.get("urdf_height_offset", None) is None:
                scene["urdf_height_offset"] = abs(get_lowest_z_world(urdf))

            self.report(
                {"WARNING"},
                "Foot Configuration is incomplete or invalid. "
                "Using generic floor offsets; configure Left/Right Foot bones for stable foot contact.",
            )

        self.report({"INFO"}, f"Calibrated {count} bones. Reference set.")
        return {"FINISHED"}


class OT_AddBVHBone(Operator):
    """Add a new URDF bone entry to a BVH mapping."""

    bl_idname = "object.add_urdf_bone"
    bl_label = "Add URDF Bone"
    bl_description = "Add URDF Bone to Mapping"
    bvh_bone_name: bpy.props.StringProperty()

    def execute(self, context):
        """Add a new URDF bone to the mapping."""
        m = next(
            i
            for i in context.scene.bvh_mapping_settings.mappings
            if i.bvh_bone_name == self.bvh_bone_name
        )
        m.urdf_bones.add()
        return {"FINISHED"}


class OT_RemoveBVHBone(Operator):
    """Remove a URDF bone entry from a BVH mapping."""

    bl_idname = "object.remove_urdf_bone"
    bl_label = "Remove URDF Bone"
    bl_description = "Remove URDF Bone from Mapping"
    bvh_bone_name: bpy.props.StringProperty()

    def execute(self, context):
        """Remove the selected URDF bone from the mapping."""
        m = next(
            i
            for i in context.scene.bvh_mapping_settings.mappings
            if i.bvh_bone_name == self.bvh_bone_name
        )
        m.urdf_bones.remove(context.scene.bvh_mapping_settings.active_urdf_index)
        return {"FINISHED"}


class OT_AddKinematicChain(Operator):
    """Add a new kinematic IK chain definition."""

    bl_idname = "object.add_kinematic_chain"
    bl_label = "Add Kinematic Chain"
    bl_description = "Add a BVH target to URDF chain mapping for IK retargeting"

    def execute(self, context):
        settings = context.scene.bvh_mapping_settings
        chain = settings.kinematic_chains.add()
        chain.label = f"Chain {len(settings.kinematic_chains)}"
        settings.active_kinematic_chain_index = len(settings.kinematic_chains) - 1
        return {"FINISHED"}


class OT_RemoveKinematicChain(Operator):
    """Remove the selected kinematic IK chain definition."""

    bl_idname = "object.remove_kinematic_chain"
    bl_label = "Remove Kinematic Chain"
    bl_description = "Remove the selected BVH target to URDF chain mapping"

    def execute(self, context):
        settings = context.scene.bvh_mapping_settings
        if not settings.kinematic_chains:
            return {"CANCELLED"}

        index = settings.active_kinematic_chain_index
        index = max(0, min(index, len(settings.kinematic_chains) - 1))
        settings.kinematic_chains.remove(index)
        settings.active_kinematic_chain_index = max(0, index - 1)
        return {"FINISHED"}


class OT_ExportMappingJSON(Operator, ExportHelper):
    """Export current mapping and kinematic chains as JSON preset."""

    bl_idname = "object.export_mapping_json"
    bl_label = "Export Mapping JSON"
    bl_description = "Save BVH/URDF mapping and kinematic chains as a JSON preset"

    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={"HIDDEN"})

    def execute(self, context):
        scene = context.scene
        settings = scene.bvh_mapping_settings

        urdf_name = scene.urdf_rig_object.name if scene.urdf_rig_object else ""
        bvh_name = scene.bvh_rig_object.name if scene.bvh_rig_object else ""

        metadata = {
            "preset_name": settings.mapping_preset_name,
            "robot_profile": settings.mapping_robot_profile,
            "mocap_profile": settings.mapping_mocap_profile,
            "urdf_rig_name": urdf_name,
            "bvh_rig_name": bvh_name,
        }
        export_mapping_to_json(self.filepath, settings, metadata=metadata)

        self.report(
            {"INFO"},
            f"Mapping preset exported: {os.path.basename(self.filepath)}",
        )
        return {"FINISHED"}


class OT_ImportMappingJSON(Operator, ImportHelper):
    """Import mapping and kinematic chains from JSON preset."""

    bl_idname = "object.import_mapping_json"
    bl_label = "Import Mapping JSON"
    bl_description = "Load BVH/URDF mapping and kinematic chains from a JSON preset"

    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={"HIDDEN"})

    def execute(self, context):
        scene = context.scene
        settings = scene.bvh_mapping_settings

        metadata = import_mapping_from_json(self.filepath, settings)

        # Keep metadata in UI so users can maintain human-readable presets.
        settings.mapping_preset_name = metadata.get("preset_name", "")
        settings.mapping_robot_profile = metadata.get("robot_profile", "")
        settings.mapping_mocap_profile = metadata.get("mocap_profile", "")

        # Soft compatibility warning: preset target/source profile vs. current rigs.
        current_urdf = scene.urdf_rig_object.name if scene.urdf_rig_object else ""
        current_bvh = scene.bvh_rig_object.name if scene.bvh_rig_object else ""
        preset_urdf = metadata.get("urdf_rig_name", "")
        preset_bvh = metadata.get("bvh_rig_name", "")

        mismatch = []
        if preset_urdf and current_urdf and preset_urdf != current_urdf:
            mismatch.append(f"URDF preset={preset_urdf}, scene={current_urdf}")
        if preset_bvh and current_bvh and preset_bvh != current_bvh:
            mismatch.append(f"BVH preset={preset_bvh}, scene={current_bvh}")

        if mismatch:
            self.report(
                {"WARNING"},
                "Preset may not match current rig pair: " + " | ".join(mismatch),
            )

        # Quaternion warning only (no conversion), as requested.
        non_quat_bvh = count_non_quaternion_bones(scene.bvh_rig_object)
        non_quat_urdf = count_non_quaternion_bones(scene.urdf_rig_object)
        if non_quat_bvh > 0 or non_quat_urdf > 0:
            self.report(
                {"WARNING"},
                (
                    "Detected non-quaternion rotation mode bones "
                    f"(BVH={non_quat_bvh}, URDF={non_quat_urdf}). "
                    "Please convert in Blender if needed."
                ),
            )

        self.report(
            {"INFO"},
            f"Mapping preset imported: {os.path.basename(self.filepath)}",
        )
        return {"FINISHED"}


class OT_LoadMappingPresetLibrary(Operator):
    """Load selected preset from bundled preset library folder."""

    bl_idname = "object.load_mapping_preset_library"
    bl_label = "Load Library Preset"
    bl_description = "Load selected preset from urdf_retargeting/presets/mappings"

    def execute(self, context):
        scene = context.scene
        settings = scene.bvh_mapping_settings
        preset_file = settings.mapping_library_preset

        if not preset_file:
            self.report({"ERROR"}, "No library preset selected.")
            return {"CANCELLED"}

        path = os.path.join(get_preset_library_dir(), preset_file)
        if not os.path.isfile(path):
            self.report({"ERROR"}, f"Preset not found: {preset_file}")
            return {"CANCELLED"}

        metadata = import_mapping_from_json(path, settings)
        settings.mapping_preset_name = metadata.get("preset_name", "")
        settings.mapping_robot_profile = metadata.get("robot_profile", "")
        settings.mapping_mocap_profile = metadata.get("mocap_profile", "")

        self.report({"INFO"}, f"Loaded library preset: {preset_file}")
        return {"FINISHED"}


class OT_SaveMappingPresetLibrary(Operator):
    """Save current mapping to bundled preset library folder."""

    bl_idname = "object.save_mapping_preset_library"
    bl_label = "Save To Library"
    bl_description = "Save current mapping preset to urdf_retargeting/presets/mappings"

    def execute(self, context):
        scene = context.scene
        settings = scene.bvh_mapping_settings

        if not settings.mapping_preset_name.strip():
            self.report(
                {"ERROR"},
                "Preset Name is required before saving to library.",
            )
            return {"CANCELLED"}

        directory = ensure_preset_library_dir()
        filename = sanitize_preset_filename(settings.mapping_preset_name)
        path = os.path.join(directory, filename)

        metadata = {
            "preset_name": settings.mapping_preset_name,
            "robot_profile": settings.mapping_robot_profile,
            "mocap_profile": settings.mapping_mocap_profile,
            "urdf_rig_name": (
                scene.urdf_rig_object.name if scene.urdf_rig_object else ""
            ),
            "bvh_rig_name": scene.bvh_rig_object.name if scene.bvh_rig_object else "",
        }
        export_mapping_to_json(path, settings, metadata=metadata)
        settings.mapping_library_preset = filename

        self.report({"INFO"}, f"Saved library preset: {filename}")
        return {"FINISHED"}


class IMPORT_OT_urdf_humanoid(Operator, ImportHelper):
    """Import and rig a URDF humanoid robot for retargeting."""

    bl_idname = "import_scene.urdf_humanoid"
    bl_label = "Import URDF"
    bl_description = (
        "Imports a URDF humanoid robot and creates an armature with bound meshes."
    )
    filename_ext = ".urdf"

    def execute(self, context):
        """Parse URDF and create rig."""
        robot = parse_urdf(self.filepath)
        arm, link_mats = create_urdf_armature(robot)
        bind_meshes(robot, arm, link_mats, os.path.dirname(self.filepath))

        context.scene.urdf_rig_object = arm

        # Store movable joints for export
        arm["urdf_joint_order"] = [
            j.name
            for j in robot.joints.values()
            if j.type in {"revolute", "continuous", "prismatic"}
        ]

        return {"FINISHED"}


def menu_func_import(self, context):
    """Add import option to File > Import menu."""
    self.layout.operator(
        IMPORT_OT_urdf_humanoid.bl_idname, text="URDF Humanoid (.urdf)"
    )


class OT_ClearScene(Operator):
    """Delete addon-created rigs and clear runtime caches (confirm required)."""

    bl_idname = "object.clear_retarget_scene"
    bl_label = "Clear Scene (Delete Addon Objects & Caches)"
    bl_description = "Remove only objects created by this addon and clear related caches (irreversible)"

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene

        # Disable live retargeting if present
        try:
            scene.bvh_mapping_settings.live_retarget = False
        except Exception:
            pass

        # Helper: check if object is safe to delete (addon-owned)
        def is_addon_object(obj):
            """
            Return True only if object has both:
            - An addon-specific property marker (_link_to_bone, urdf_joint_order)
            - AND an addon naming pattern (_smoothed, _mesh_, _Rig)
            """
            has_addon_prop = (
                obj.get("_link_to_bone") is not None
                or obj.get("urdf_joint_order") is not None
            )
            has_addon_name = (
                obj.name.endswith("_smoothed")
                or "_mesh_" in obj.name
                or obj.name.endswith("_Rig")
            )
            return has_addon_prop and has_addon_name

        # Collect scene-referenced rigs (these are always addon-owned)
        scene_ref_objs = set()
        for key in ("smoothed_bvh_rig_object", "bvh_rig_object", "urdf_rig_object"):
            obj = scene.get(key)
            if obj and isinstance(obj, bpy.types.Object):
                scene_ref_objs.add(obj.name)

        to_delete = set()

        # Add scene-referenced rigs
        to_delete.update(scene_ref_objs)

        # Add objects that pass the strict addon check
        for obj in bpy.data.objects:
            if is_addon_object(obj):
                to_delete.add(obj.name)

        # Include children of addon objects
        for obj in list(bpy.data.objects):
            if obj.parent and obj.parent.name in to_delete:
                to_delete.add(obj.name)

        removed = []
        # Delete collected addon objects only
        for name in list(to_delete):
            if name in bpy.data.objects:
                obj = bpy.data.objects[name]
                # Remove action if strictly linked to this object
                if obj.animation_data and obj.animation_data.action:
                    act = obj.animation_data.action
                    try:
                        bpy.data.actions.remove(act, do_unlink=True)
                    except Exception:
                        pass
                try:
                    bpy.data.objects.remove(obj, do_unlink=True)
                    removed.append(name)
                except Exception:
                    pass

        # Clean orphan datablocks that may have been created by addon
        for mesh in list(bpy.data.meshes):
            if mesh.users == 0:
                try:
                    bpy.data.meshes.remove(mesh, do_unlink=True)
                except Exception:
                    pass
        for arm in list(bpy.data.armatures):
            if arm.users == 0:
                try:
                    bpy.data.armatures.remove(arm, do_unlink=True)
                except Exception:
                    pass
        for mat in list(bpy.data.materials):
            if mat.users == 0:
                try:
                    bpy.data.materials.remove(mat, do_unlink=True)
                except Exception:
                    pass
        for act in list(bpy.data.actions):
            if act.users == 0:
                try:
                    bpy.data.actions.remove(act, do_unlink=True)
                except Exception:
                    pass

        # Clear transient scene keys (calibration and runtime)
        for k in (
            "_persistent_foot_correction",
            "_active_anchor_name",
            "_anchor_world_pos_xy",
            "_foot_positions",
            "_bvh_smooth_cache",
            "urdf_foot_height_offset",
            "ref_root_pos",
            "ref_root_rot",
            "bvh_floor_offset",
            "urdf_height_offset",
        ):
            if k in scene:
                try:
                    del scene[k]
                except Exception:
                    pass

        # Clear addon-specific object properties from remaining objects
        for obj in bpy.data.objects:
            if obj.name in removed:
                continue
            for prop in ("_link_to_bone", "urdf_joint_order"):
                if prop in obj:
                    try:
                        del obj[prop]
                    except Exception:
                        pass

        # Clear scene pointers
        for key in ("smoothed_bvh_rig_object", "bvh_rig_object", "urdf_rig_object"):
            if key in scene:
                try:
                    del scene[key]
                except Exception:
                    pass

        self.report({"INFO"}, f"Cleared addon objects: {len(removed)}")
        return {"FINISHED"}
