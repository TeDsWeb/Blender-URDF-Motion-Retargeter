bl_info = {
    "name": "URDF Retargeting",
    "author": "Dominik Brämer",
    "version": (1, 0, 0),
    "blender": (5, 0, 0),
    "location": "File > Import > URDF Humanoid",
    "description": "URDF Import + BVH mapping with interactive N-Panel (BVH → URDF) using UILists",
    "category": "Import-Export",
    "type": "add-on",
}

import bpy
import os
import math
import mathutils
from bpy_extras.io_utils import ImportHelper
import xml.etree.ElementTree as ET
from bpy.props import (
    StringProperty,
    PointerProperty,
    CollectionProperty,
    IntProperty,
    EnumProperty,
    BoolProperty,
    FloatVectorProperty,
)
from bpy.types import PropertyGroup, Operator, Panel, UIList
from bpy.app.handlers import persistent


# ============================================================
# URDF DATA STRUCTURES
# ============================================================
class URDFVisual:
    def __init__(self, xyz, rpy, mesh):
        self.xyz = xyz
        self.rpy = rpy
        self.mesh = mesh

class URDFLink:
    def __init__(self, name):
        self.name = name
        self.visuals = []

class URDFJoint:
    def __init__(self, name, jtype, parent, child, xyz, rpy, axis):
        self.name = name
        self.type = jtype
        self.parent = parent
        self.child = child
        self.xyz = xyz
        self.rpy = rpy
        self.axis = axis

class URDFRobot:
    def __init__(self, name):
        self.name = name
        self.links = {}
        self.joints = {}

# ============================================================
# URDF PARSER
# ============================================================
def parse_float_list(s, n):
    if s is None:
        return [0.0] * n
    parts = s.replace(',', ' ').split()
    vals = []
    for p in parts:
        try:
            vals.append(float(p))
        except:
            vals.append(0.0)
    while len(vals) < n:
        vals.append(0.0)
    return vals[:n]

def parse_urdf(path):
    tree = ET.parse(path)
    root = tree.getroot()
    robot = URDFRobot(root.attrib.get("name", "URDF_Robot"))

    for link_el in root.findall("link"):
        link = URDFLink(link_el.attrib["name"])
        for vis_el in link_el.findall("visual"):
            org = vis_el.find("origin")
            xyz = parse_float_list(org.attrib.get("xyz") if org is not None else None, 3)
            rpy = parse_float_list(org.attrib.get("rpy") if org is not None else None, 3)
            geom = vis_el.find("geometry")
            mesh_el = geom.find("mesh") if geom is not None else None
            mesh = mesh_el.attrib.get("filename") if mesh_el is not None else None
            if mesh:
                link.visuals.append(URDFVisual(xyz, rpy, mesh))
        robot.links[link.name] = link

    for idx, joint_el in enumerate(root.findall("joint")):
        name = joint_el.attrib.get("name", "joint_%03d" % idx)
        jtype = joint_el.attrib.get("type", "fixed")
        parent = joint_el.find("parent").attrib["link"]
        child = joint_el.find("child").attrib["link"]
        org = joint_el.find("origin")
        xyz = parse_float_list(org.attrib.get("xyz") if org is not None else None, 3)
        rpy = parse_float_list(org.attrib.get("rpy") if org is not None else None, 3)
        axis_el = joint_el.find("axis")
        axis = parse_float_list(axis_el.attrib.get("xyz") if axis_el is not None else None, 3)
        joint = URDFJoint(name, jtype, parent, child, xyz, rpy, axis)
        robot.joints[name] = joint
    return robot

# ============================================================
# UTILITY
# ============================================================
def origin_to_matrix(xyz, rpy):
    loc = mathutils.Vector(xyz)
    rot = mathutils.Euler(rpy, 'XYZ').to_matrix().to_4x4()
    return mathutils.Matrix.Translation(loc) @ rot

def axis_to_vec(axis):
    v = mathutils.Vector(axis)
    return v.normalized() if v.length > 0 else mathutils.Vector((0, 0, 1))

def resolve_mesh_path(mesh, base_path):
    if mesh.startswith("package://"):
        mesh = mesh.replace("package://", "")
        parts = mesh.split("/", 1)
        if len(parts) == 2:
            mesh = parts[1]
    return os.path.normpath(os.path.join(base_path, mesh))

# ============================================================
# URDF ARMATURE + MESHES
# ============================================================
def build_link_transforms(robot):
    children = {}
    joint_by_child = {}
    for j in robot.joints.values():
        children.setdefault(j.parent, []).append(j)
        joint_by_child[j.child] = j
    all_links = set(l.name for l in robot.links.values())
    child_links = set(joint_by_child.keys())
    roots = list(all_links - child_links)
    root = roots[0] if roots else list(all_links)[0]
    mats = {root: mathutils.Matrix.Identity(4)}
    stack = [root]
    while stack:
        parent = stack.pop()
        parent_mat = mats[parent]
        for j in children.get(parent, []):
            T = origin_to_matrix(j.xyz, j.rpy)
            mats[j.child] = parent_mat @ T
            stack.append(j.child)
    return mats, root

def create_urdf_armature(robot):
    link_mats, root = build_link_transforms(robot)
    bpy.ops.object.add(type='ARMATURE', enter_editmode=True)
    arm_obj = bpy.context.object
    arm_obj.name = f"{robot.name}_URDF_Rig"
    arm = arm_obj.data
    bones = arm.edit_bones
    link_to_bone = {}
    bone_len = 0.05
    for j in robot.joints.values():
        b = bones.new(j.child)
        link_to_bone[j.child] = b
    for j in robot.joints.values():
        b = link_to_bone[j.child]
        child_mat = link_mats[j.child]
        head = child_mat.to_translation()
        joint_rot = mathutils.Euler(j.rpy, 'XYZ').to_matrix()
        parent_rot = link_mats[j.parent].to_3x3()
        axis_local = mathutils.Vector(j.axis)
        axis_world = (parent_rot @ joint_rot @ axis_local).normalized()
        tail = head + axis_world * bone_len
        b.head = head
        b.tail = tail
        b.align_roll(mathutils.Vector((0, 0, 1)))
        if j.parent in link_to_bone:
            b.parent = link_to_bone[j.parent]
    bpy.ops.object.mode_set(mode='POSE')
    for pb in arm_obj.pose.bones:
        pb.rotation_mode = 'XYZ'
    bpy.ops.object.mode_set(mode='OBJECT')
    return arm_obj, link_mats

def import_mesh(mesh_path):
    ext = os.path.splitext(mesh_path)[1].lower()
    mesh_path = os.path.normpath(mesh_path)
    if ext == ".stl":
        bpy.ops.wm.stl_import(filepath=mesh_path)
    elif ext == ".obj":
        bpy.ops.import_scene.obj(filepath=mesh_path)
    elif ext == ".dae":
        bpy.ops.wm.collada_import(filepath=mesh_path)
    else:
        return None
    return bpy.context.selected_objects[0]

def bind_meshes(robot, arm_obj, link_mats, base_path):
    for link in robot.links.values():
        link_mat = link_mats.get(link.name, mathutils.Matrix.Identity(4))
        for idx, vis in enumerate(link.visuals):
            mesh_path = resolve_mesh_path(vis.mesh, base_path)
            if not os.path.isfile(mesh_path):
                continue
            obj = import_mesh(mesh_path)
            if not obj:
                continue
            obj.name = f"{link.name}_{idx}"
            obj.matrix_world = link_mat @ origin_to_matrix(vis.xyz, vis.rpy)
            obj.parent = arm_obj
            obj.parent_type = 'OBJECT'

# ============================================================
# Multi-BVH Mapping (mit UILists)
# ============================================================
axis_items = [
    ('X', "X", ""),
    ('Y', "Y", ""),
    ('Z', "Z", ""),
]

sign_items = [
    ('POS', "+", ""),
    ('NEG', "−", ""),
]

class BVHMappingBone(PropertyGroup):
    # URDF-Bone, auf den gemappt wird
    bvh_bone_name: StringProperty(name="URDF Bone")

    # Welche BVH-Euler-Achse soll verwendet werden?
    source_axis: EnumProperty(
        name="BVH Axis",
        items=axis_items,
        default='X',
    )

    # Vorzeichen
    sign: EnumProperty(
        name="Sign",
        items=sign_items,
        default='NEG',
    )

class BVHMappingItem(PropertyGroup):
    urdf_bones: CollectionProperty(type=BVHMappingBone)
    bvh_bone_name: StringProperty(name="BVH Bone")
    ref_rot: FloatVectorProperty(size=4)

class BVHMappingSettings(PropertyGroup):
    mappings: CollectionProperty(type=BVHMappingItem)
    active_mapping_index: IntProperty(default=0)
    active_urdf_index: IntProperty(default=0)
    live_retarget: BoolProperty(
        name="Live Retargeting",
        default=False
    )

# UILists
class UL_BVHMappingList(UIList):
    bl_idname = "UL_BVHMappingList"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row()
        row.label(text=item.bvh_bone_name)
        row.label(text=f"{len(item.urdf_bones)} URDF")

class UL_URDFBoneList(UIList):
    bl_idname = "UL_URDFBoneList"

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        scene = context.scene
        row = layout.row()
        if scene.urdf_rig_object:
            row.prop_search(item, "bvh_bone_name", scene.urdf_rig_object.pose, "bones", text="")
        else:
            row.label(text=item.bvh_bone_name or "<URDF Bone>")
        row.prop(item, "source_axis", text="")
        row.prop(item, "sign", text="")

# Operators
class OT_GenerateMappingList(Operator):
    bl_idname = "object.generate_mapping_list"
    bl_label = "Generate Mapping List"
    
    def execute(self, context):
        scene = context.scene
        settings = scene.bvh_mapping_settings
        bvh_rig = scene.bvh_rig_object
        if not bvh_rig:
            return {'CANCELLED'}
        
        settings.mappings.clear()
        for ub in [pb.name for pb in bvh_rig.pose.bones]:
            item = settings.mappings.add()
            item.bvh_bone_name = ub

        settings.active_mapping_index = 0
        settings.active_urdf_index = 0
        return {'FINISHED'}
    
def store_pose(pose_bones):
    return {
        pb.name: pb.matrix_basis.copy()
        for pb in pose_bones
    }

def restore_pose(pose_bones, stored):
    for pb in pose_bones:
        if pb.name in stored:
            pb.matrix_basis = stored[pb.name]

def apply_t_pose(bvh_rig):
    for pb in bvh_rig.pose.bones:
        name = pb.name.lower()

        # Einheitliche Rotation
        pb.rotation_mode = 'XYZ'
        pb.rotation_euler = (0.0, 0.0, 0.0)

        # --- ARMS ---
        if any(k in name for k in ("upperarm", "humerus", "shoulder")):
            # Arme horizontal ausrichten
            if "left" in name or name.endswith(".l"):
                pb.rotation_euler.z = math.radians(0)
            elif "right" in name or name.endswith(".r"):
                pb.rotation_euler.z = math.radians(0)

        elif any(k in name for k in ("forearm", "lowerarm", "elbow")):
            # Unterarme folgen der Oberarmrotation
            if "left" in name or name.endswith(".l"):
                pb.rotation_euler.z = math.radians(0)
            elif "right" in name or name.endswith(".r"):
                pb.rotation_euler.z = math.radians(0)

        elif any(k in name for k in ("hand", "wrist")):
            # Hände ebenfalls horizontal
            if "left" in name or name.endswith(".l"):
                pb.rotation_euler.z = math.radians(90)
            elif "right" in name or name.endswith(".r"):
                pb.rotation_euler.z = math.radians(-90)

        # --- LEGS ---
        elif any(k in name for k in ("thigh", "upperleg", "upleg")):
            pb.rotation_euler = (0.0, 0.0, 0.0)

        elif any(k in name for k in ("calf", "lowerleg", "shin")):
            pb.rotation_euler = (0.0, 0.0, 0.0)

        elif "foot" in name or "toe" in name:
            pb.rotation_euler = (0.0, 0.0, 0.0)

def capture_reference_offsets(scene):
    settings = scene.bvh_mapping_settings
    bvh_rig = scene.bvh_rig_object

    for item in settings.mappings:
        bvh_b = bvh_rig.pose.bones.get(item.bvh_bone_name)
        if not bvh_b:
            continue

        q = bvh_b.matrix_basis.to_quaternion()
        item.ref_rot = (q.w, q.x, q.y, q.z)

class OT_ApplyBVHMapping(bpy.types.Operator):
    bl_idname = "object.apply_bvh_mapping"
    bl_label = "Apply Mapping (Setup)"
    
    def execute(self, context):
        scene = context.scene
        settings = scene.bvh_mapping_settings
        urdf_rig = scene.urdf_rig_object
        bvh_rig = scene.bvh_rig_object

        current_frame = scene.frame_current
        scene.frame_set(0)

        if not urdf_rig or not bvh_rig:
            self.report({'ERROR'}, "URDF or BVH rig missing")
            return {'CANCELLED'}

        # --- AUTO T-POSE + OFFSET CAPTURE ---
        stored_pose = store_pose(bvh_rig.pose.bones)
        apply_t_pose(bvh_rig)
        capture_reference_offsets(scene)
        restore_pose(bvh_rig.pose.bones, stored_pose)
        scene.frame_set(current_frame)

        if not urdf_rig:
            self.report({'ERROR'}, "No URDF rig selected")
            return {'CANCELLED'}

        # 1) Alle alten Constraints entfernen
        for pb in urdf_rig.pose.bones:
            for c in list(pb.constraints):
                pb.constraints.remove(c)

        # 2) Alle Offsets zurücksetzen
        for pb in urdf_rig.pose.bones:
            if "offset" in pb:
                del pb["offset"]

        # 3) Live Retarget aktivieren
        settings.live_retarget = True

        # 4) Einmaliges Retargeting ausführen
        retarget_frame(scene)

        self.report({'INFO'}, "Mapping applied and offsets reset")
        return {'FINISHED'}

class OT_AddBVHBone(Operator):
    bl_idname = "object.add_urdf_bone"
    bl_label = "Add URDF Bone"
    
    bvh_bone_name: StringProperty()

    def execute(self, context):
        scene = context.scene
        settings = scene.bvh_mapping_settings

        for item in settings.mappings:
            if item.bvh_bone_name == self.bvh_bone_name:
                new_bone = item.urdf_bones.add()
                new_bone.bvh_bone_name = ""
                new_bone.source_axis = 'X'
                new_bone.sign = 'NEG'

        return {'FINISHED'}

class OT_RemoveBVHBone(Operator):
    bl_idname = "object.remove_urdf_bone"
    bl_label = "Remove URDF Bone"
    
    bvh_bone_name: StringProperty()
    index: IntProperty()
    
    def execute(self, context):
        scene = context.scene
        settings = scene.bvh_mapping_settings

        for item in settings.mappings:
            if item.bvh_bone_name == self.bvh_bone_name:
                if 0 <= self.index < len(item.urdf_bones):
                    item.urdf_bones.remove(self.index)

        return {'FINISHED'}

class OT_ResetBVHMapping(Operator):
    bl_idname = "object.reset_bvh_mapping"
    bl_label = "Reset Mapping List"
    
    def execute(self, context):
        context.scene.bvh_mapping_settings.mappings.clear()
        context.scene.bvh_mapping_settings.active_mapping_index = 0
        context.scene.bvh_mapping_settings.active_urdf_index = 0
        return {'FINISHED'}
    
class OT_DebugTPose(Operator):
    bl_idname = "object.debug_bvh_tpose"
    bl_label = "Show BVH T-Pose"
    bl_description = "Temporarily pose the BVH rig into a T-pose for debugging"

    def execute(self, context):
        scene = context.scene
        bvh_rig = scene.bvh_rig_object

        if not bvh_rig:
            self.report({'ERROR'}, "No BVH rig selected")
            return {'CANCELLED'}

        apply_t_pose(bvh_rig)

        self.report({'INFO'}, "BVH rig posed into T-pose (not captured)")
        return {'FINISHED'}

# ============================================================
# N-Panel UI
# ============================================================
class PANEL_BVHMapping(Panel):
    bl_label = "BVH -> URDF Mapping"
    bl_idname = "VIEW3D_PT_bvh_mapping"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'URDF Retarget'
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        settings = scene.bvh_mapping_settings

        layout.prop(scene, "urdf_rig_object")
        layout.prop(scene, "bvh_rig_object")
        layout.prop(settings, "live_retarget")

        row = layout.row()
        row.operator("object.generate_mapping_list", text="Generate Mapping List")
        row.operator("object.reset_bvh_mapping", text="Reset")

        layout.operator("object.apply_bvh_mapping", text="Apply Mapping")

        layout.operator(
            "object.debug_bvh_tpose",
            text="Show BVH T-Pose",
            icon="ARMATURE_DATA"
        )

        if not settings.mappings:
            layout.label(text="Click 'Generate Mapping List' to show bones.")
            return

        box = layout.box()
        box.label(text="BVH Bones")
        box.template_list(
            "UL_BVHMappingList",
            "",
            settings,
            "mappings",
            settings,
            "active_mapping_index",
        )

        if 0 <= settings.active_mapping_index < len(settings.mappings):
            active_item = settings.mappings[settings.active_mapping_index]

            box2 = layout.box()
            box2.label(text=f"URDF Bones for: {active_item.bvh_bone_name}")

            row = box2.row()
            row.template_list(
                "UL_URDFBoneList",
                "",
                active_item,
                "urdf_bones",
                settings,
                "active_urdf_index",
            )

            col = row.column(align=True)
            add = col.operator("object.add_urdf_bone", text="", icon="ADD")
            add.bvh_bone_name = active_item.bvh_bone_name

            rem = col.operator("object.remove_urdf_bone", text="", icon="REMOVE")
            rem.bvh_bone_name = active_item.bvh_bone_name
            rem.index = settings.active_urdf_index

# ============================================================
# Import URDF Operator
# ============================================================
class IMPORT_OT_urdf_humanoid(Operator, ImportHelper):
    bl_idname = "import_scene.urdf_humanoid"
    bl_label = "Import URDF Humanoid"
    filename_ext = ".urdf"
    
    def execute(self, context):
        urdf_path = os.path.normpath(self.filepath)
        base_path = os.path.dirname(urdf_path)
        robot = parse_urdf(urdf_path)
        urdf_arm, link_mats = create_urdf_armature(robot)
        #bind_meshes(robot, urdf_arm, link_mats, base_path)
        context.scene.urdf_rig_object = urdf_arm
        return {'FINISHED'}

# ============================================================
# RETARGET
# ============================================================
@persistent
def retarget_frame(scene):
    settings = scene.bvh_mapping_settings
    if not getattr(settings, "live_retarget", False):
        return

    urdf_rig = scene.urdf_rig_object
    bvh_rig = scene.bvh_rig_object
    if not urdf_rig or not bvh_rig:
        return

    for item in settings.mappings:
        bvh_b = bvh_rig.pose.bones.get(item.bvh_bone_name)
        if not bvh_b:
            continue

        ref_q = mathutils.Quaternion(item.ref_rot)
        cur_q = bvh_b.matrix_basis.to_quaternion()
        rot_bvh = ref_q.inverted() @ cur_q
        e_bvh = rot_bvh.to_euler('XYZ')

        def get_axis(euler, axis_char):
            if axis_char == 'X':
                return euler.x
            if axis_char == 'Y':
                return euler.y
            if axis_char == 'Z':
                return euler.z
            return 0.0

        for b in item.urdf_bones:
            urdf_b = urdf_rig.pose.bones.get(b.bvh_bone_name)
            if not urdf_b:
                continue

            value = get_axis(e_bvh, b.source_axis)
            if b.sign == 'NEG':
                value = -value

            key = "offset"
            if key not in urdf_b:
                urdf_b[key] = value
            value -= urdf_b[key]

            # Zielachse im URDF: immer Y
            urdf_b.rotation_euler = (0.0, value, 0.0)

# ============================================================
# REGISTER
# ============================================================
classes = [
    URDFVisual,
    URDFLink,
    URDFJoint,
    URDFRobot,
    BVHMappingBone,
    BVHMappingItem,
    BVHMappingSettings,
    UL_BVHMappingList,
    UL_URDFBoneList,
    OT_GenerateMappingList,
    OT_AddBVHBone,
    OT_RemoveBVHBone,
    OT_ApplyBVHMapping,
    OT_ResetBVHMapping,
    OT_DebugTPose,
    PANEL_BVHMapping,
    IMPORT_OT_urdf_humanoid,
]

def menu_func_import(self, context):
    self.layout.operator(IMPORT_OT_urdf_humanoid.bl_idname, text="URDF Humanoid (.urdf)")

def register():
    for attr in ("bvh_mapping_settings", "urdf_rig_object", "bvh_rig_object"):
        if hasattr(bpy.types.Scene, attr):
            try:
                delattr(bpy.types.Scene, attr)
            except Exception:
                pass
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except RuntimeError:
            pass
    bpy.types.Scene.bvh_mapping_settings = PointerProperty(type=BVHMappingSettings)
    bpy.types.Scene.urdf_rig_object = PointerProperty(name="URDF Rig", type=bpy.types.Object)
    bpy.types.Scene.bvh_rig_object = PointerProperty(name="BVH Rig", type=bpy.types.Object)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    if retarget_frame not in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.append(retarget_frame)

def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    if retarget_frame in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.remove(retarget_frame)

    for attr in ("bvh_mapping_settings", "urdf_rig_object", "bvh_rig_object"):
        if hasattr(bpy.types.Scene, attr):
            try:
                delattr(bpy.types.Scene, attr)
            except Exception:
                pass

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass

if __name__ == "__main__":
    register()