bl_info = {
    "name": "URDF Retargeting",
    "author": "Dominik Brämer",
    "version": (1, 0, 0),
    "blender": (5, 0, 0),
    "location": "File > Import > URDF Humanoid",
    "description": "URDF Import + BVH mapping with beyond_mimic export",
    "category": "Import-Export",
    "type": "add-on",
}

import bpy
import os
import csv
import json
import math
import mathutils
from bpy_extras.io_utils import ImportHelper
import xml.etree.ElementTree as ET
from bpy.props import (
    StringProperty,
    PointerProperty,
    CollectionProperty,
    IntProperty,
    EnumProperty,
    BoolProperty,
    FloatVectorProperty,
    FloatProperty,
)
from bpy.types import PropertyGroup, Operator, Panel, UIList
from bpy.app.handlers import persistent
from bpy_extras.anim_utils import action_get_channelbag_for_slot

# ============================================================
# URDF DATA STRUCTURES & PARSER
# ============================================================


class URDFVisual:
    def __init__(self, xyz, rpy, mesh):
        self.xyz = xyz
        self.rpy = rpy
        self.mesh = mesh


class URDFLink:
    def __init__(self, name):
        self.name = name
        self.visuals = []


class URDFJoint:
    def __init__(
        self,
        name,
        jtype,
        parent,
        child,
        xyz,
        rpy,
        axis,
        limit_lower=None,
        limit_upper=None,
        velocity_limit=None,
        soft_limit_lower=None,
        soft_limit_upper=None,
    ):
        self.name = name
        self.type = jtype
        self.parent = parent
        self.child = child
        self.xyz = xyz
        self.rpy = rpy
        self.axis = axis
        self.limit_lower = limit_lower
        self.limit_upper = limit_upper
        self.velocity_limit = velocity_limit
        self.soft_limit_lower = soft_limit_lower
        self.soft_limit_upper = soft_limit_upper


class URDFRobot:
    def __init__(self, name):
        self.name = name
        self.links = {}
        self.joints = {}


def parse_float_list(s, n):
    """Parses a string of space/comma separated floats."""
    if s is None:
        return [0.0] * n
    parts = s.replace(",", " ").split()
    vals = []
    for p in parts:
        try:
            vals.append(float(p))
        except:
            vals.append(0.0)
    while len(vals) < n:
        vals.append(0.0)
    return vals[:n]


def parse_urdf(path):
    """Parses the URDF XML file into a URDFRobot structure."""
    tree = ET.parse(path)
    root = tree.getroot()
    robot = URDFRobot(root.attrib.get("name", "URDF_Robot"))

    for link_el in root.findall("link"):
        link = URDFLink(link_el.attrib["name"])
        for vis_el in link_el.findall("visual"):
            org = vis_el.find("origin")
            xyz = parse_float_list(
                org.attrib.get("xyz") if org is not None else None, 3
            )
            rpy = parse_float_list(
                org.attrib.get("rpy") if org is not None else None, 3
            )
            geom = vis_el.find("geometry")
            mesh_el = geom.find("mesh") if geom is not None else None
            mesh = mesh_el.attrib.get("filename") if mesh_el is not None else None
            if mesh:
                link.visuals.append(URDFVisual(xyz, rpy, mesh))
        robot.links[link.name] = link

    for idx, joint_el in enumerate(root.findall("joint")):
        # Use the actual 'name' attribute from the URDF joint element
        name = joint_el.attrib.get("name")
        if not name:
            name = f"joint_{idx:03d}"  # Fallback only if attribute is missing
        jtype = joint_el.attrib.get("type", "fixed")
        parent = joint_el.find("parent").attrib["link"]
        child = joint_el.find("child").attrib["link"]
        org = joint_el.find("origin")
        xyz = parse_float_list(org.attrib.get("xyz") if org is not None else None, 3)
        rpy = parse_float_list(org.attrib.get("rpy") if org is not None else None, 3)
        axis_el = joint_el.find("axis")
        axis = parse_float_list(
            axis_el.attrib.get("xyz") if axis_el is not None else None, 3
        )
        limit_el = joint_el.find("limit")
        lower = (
            float(limit_el.attrib.get("lower", -3.14159))
            if limit_el is not None
            else None
        )
        upper = (
            float(limit_el.attrib.get("upper", 3.14159))
            if limit_el is not None
            else None
        )
        velocity = (
            float(limit_el.get("velocity", 10.0)) if limit_el is not None else 10.0
        )
        safety_el = joint_el.find("safety_controller")
        soft_limit_lower = (
            float(safety_el.attrib.get("soft_lower_limit"))
            if safety_el is not None and "soft_lower_limit" in safety_el.attrib
            else None
        )
        soft_limit_upper = (
            float(safety_el.attrib.get("soft_upper_limit"))
            if safety_el is not None and "soft_upper_limit" in safety_el.attrib
            else None
        )
        robot.joints[name] = URDFJoint(
            name,
            jtype,
            parent,
            child,
            xyz,
            rpy,
            axis,
            lower,
            upper,
            velocity,
            soft_limit_lower,
            soft_limit_upper,
        )
    return robot


# ============================================================
# BUILDING & BINDING
# ============================================================


def origin_to_matrix(xyz, rpy):
    """Converts URDF origin (xyz, rpy) to a 4x4 Transformation Matrix."""
    loc = mathutils.Vector(xyz)
    rot = mathutils.Euler(rpy, "XYZ").to_matrix().to_4x4()
    return mathutils.Matrix.Translation(loc) @ rot


def build_link_transforms(robot):
    """Computes world matrices for all links in their default pose."""
    children = {}
    joint_by_child = {}
    for j in robot.joints.values():
        children.setdefault(j.parent, []).append(j)
        joint_by_child[j.child] = j
    all_links = set(l.name for l in robot.links.values())
    roots = list(all_links - set(joint_by_child.keys()))
    root = roots[0] if roots else list(all_links)[0]
    mats = {root: mathutils.Matrix.Identity(4)}
    stack = [root]
    while stack:
        p = stack.pop()
        for j in children.get(p, []):
            mats[j.child] = mats[p] @ origin_to_matrix(j.xyz, j.rpy)
            stack.append(j.child)
    return mats, root


def create_urdf_armature(robot):
    """Creates armature with bones named after URDF JOINTS."""
    link_mats, root_link_name = build_link_transforms(robot)

    # Create the armature object
    bpy.ops.object.add(type="ARMATURE", enter_editmode=True)
    arm_obj = bpy.context.object
    arm_obj.name = f"{robot.name}_Rig"
    bones = arm_obj.data.edit_bones

    # Link Name -> Bone Name (Joint Name) mapping
    # Required because meshes belong to links, but bones are now joints
    link_to_bone_name = {root_link_name: root_link_name}
    bones.new(root_link_name)  # Root bone for the base

    # Create bones for each joint
    for j_name, j in robot.joints.items():
        bones.new(j_name)
        link_to_bone_name[j.child] = j_name

    for j in robot.joints.values():
        b = bones.get(j.name)
        if b:
            # Set bone position based on the child link's world transform
            head = link_mats[j.child].to_translation()
            joint_rot = mathutils.Euler(j.rpy, "XYZ").to_matrix()
            axis_world = (
                link_mats[j.parent].to_3x3() @ joint_rot @ mathutils.Vector(j.axis)
            ).normalized()

            b.head, b.tail = head, head + axis_world * 0.05

            # Parent to the bone that controls the parent link
            p_bone_name = link_to_bone_name.get(j.parent)
            if p_bone_name:
                b.parent = bones.get(p_bone_name)

    bpy.ops.object.mode_set(mode="OBJECT")

    # Store the mapping inside the object for the bind_meshes function
    arm_obj["_link_to_bone"] = link_to_bone_name

    # Store joint type and limits in bone custom properties for retargeting
    for j_name, j in robot.joints.items():
        if j_name in arm_obj.pose.bones:
            pb = arm_obj.pose.bones[j_name]
            if j.limit_lower is not None:
                pb["limit_lower"] = j.limit_lower
            else:
                pb["limit_lower"] = -3.14159  # Fallback

            if j.limit_upper is not None:
                pb["limit_upper"] = j.limit_upper
            else:
                pb["limit_upper"] = 3.14159  # Fallback

            if j.soft_limit_lower is not None:
                pb["limit_lower"] = (
                    j.soft_limit_lower
                )  # Override with soft limit if available

            if j.soft_limit_upper is not None:
                pb["limit_upper"] = (
                    j.soft_limit_upper
                )  # Override with soft limit if available

            if j.velocity_limit is not None:
                pb["velocity_limit"] = j.velocity_limit
            else:
                pb["velocity_limit"] = 10.0  # Fallback

            if j.type is not None:
                pb["joint_type"] = j.type
            else:
                pb["joint_type"] = "fixed"  # Fallback

    return arm_obj, link_mats


def bind_meshes(robot, arm_obj, link_mats, base_path):
    """Imports meshes and parents them to bones (named after joints)."""
    # Retrieve the mapping from the armature object
    link_to_bone_name = arm_obj.get("_link_to_bone", {})

    for link_name, link in robot.links.items():
        bone_name = link_to_bone_name.get(link_name)

        for idx, vis in enumerate(link.visuals):
            mesh_raw = vis.mesh.replace("package://", "")
            mesh_path = os.path.normpath(os.path.join(base_path, mesh_raw))
            if not os.path.exists(mesh_path):
                continue

            # CRITICAL: Deselect to ensure the imported object is the only selection
            bpy.ops.object.select_all(action="DESELECT")

            ext = os.path.splitext(mesh_path)[1].lower()
            if ext == ".stl":
                bpy.ops.wm.stl_import(filepath=mesh_path)
            elif ext == ".obj":
                bpy.ops.wm.obj_import(filepath=mesh_path)
            elif ext == ".dae":
                bpy.ops.wm.collada_import(filepath=mesh_path)

            if bpy.context.selected_objects:
                obj = bpy.context.selected_objects[0]

                # Safety check: avoid parenting the armature to itself
                if obj == arm_obj:
                    continue

                obj.name = f"{link_name}_mesh_{idx}"
                obj.parent = arm_obj

                # Parent to bone using the Joint Name from our map
                if bone_name and bone_name in arm_obj.pose.bones:
                    obj.parent_type, obj.parent_bone = "BONE", bone_name
                    bone_mtx_world = (
                        arm_obj.matrix_world @ arm_obj.pose.bones[bone_name].matrix
                    )
                    obj.matrix_parent_inverse = bone_mtx_world.inverted()

                obj.matrix_world = link_mats[link_name] @ origin_to_matrix(
                    vis.xyz, vis.rpy
                )


# ============================================================
# DATA STRUCTURES
# ============================================================


class BVHMappingBone(PropertyGroup):
    urdf_bone_name: StringProperty(name="URDF Bone")
    source_axis: EnumProperty(
        items=[("X", "X", ""), ("Y", "Y", ""), ("Z", "Z", "")], default="X"
    )
    sign: EnumProperty(items=[("POS", "+", ""), ("NEG", "-", "")], default="NEG")
    neutral_offset: FloatProperty(name="Neutral Offset", subtype="ANGLE")


class BVHMappingItem(PropertyGroup):
    urdf_bones: CollectionProperty(type=BVHMappingBone)
    bvh_bone_name: StringProperty()
    ref_rot: FloatVectorProperty(size=4, default=(1.0, 0.0, 0.0, 0.0))


class BVHMappingSettings(PropertyGroup):
    mappings: CollectionProperty(type=BVHMappingItem)
    active_mapping_index: IntProperty()
    active_urdf_index: IntProperty()
    live_retarget: BoolProperty(name="Live Retargeting")
    bvh_smoothing: FloatProperty(
        name="BVH Smoothing",
        description="Zero-Lag SLERP/LERP filter on BVH joint angles (source space)",
        default=0.9,
        min=0.0,
        max=1.0,
    )
    joint_smoothing: FloatProperty(
        name="Joint Smoothing",
        description="Low-pass EMA filter on joint angles (actuator space)",
        default=0.1,
        min=0.0,
        max=1.0,
    )
    foot_l_name: StringProperty(name="Left Foot Bone", default="")
    foot_r_name: StringProperty(name="Right Foot Bone", default="")
    jump_threshold: FloatProperty(
        name="Jump Threshold",
        description="Minimum vertical movement to register a jump (in meters)",
        default=0.01,
        min=0.0,
    )
    foot_flattening_height: FloatProperty(
        name="Flatten Height",
        description="Distance from floor (meters) where foot is fully aligned to BVH again",
        default=0.15,
        min=0.01,
        max=1.0,
    )
    foot_flattening_strength: FloatProperty(
        name="Flatten Strength",
        description="Influence of the ground alignment (1.0 = Force Flat, 0.0 = Off)",
        default=1.0,
        min=0.0,
        max=1.0,
    )
    root_scale: FloatProperty(name="Root Scale", default=1.0)
    location_offset: FloatVectorProperty(
        name="Loc Offset", subtype="TRANSLATION", size=2, default=(0.0, 0.0)
    )
    rotation_offset: FloatVectorProperty(name="Rot Offset", subtype="EULER")
    target_hz: IntProperty(name="Export Hz", default=50, min=1, max=240)


# ============================================================
# RETARGETING ENGINE
# ============================================================


@persistent
def get_lowest_z_world(urdf_obj):
    """Finds the lowest Z-coordinate of the visual mesh or bones."""
    # We find the absolute lowest Z coordinate across all mesh parts
    global_min_z = float("inf")
    found_mesh = False

    # Iterate through all objects parented to the rig (links/visuals)
    for child in urdf_obj.children:
        if child.type == "MESH":
            found_mesh = True
            # The bound_box is in local space, we need to transform it to world space
            # mesh.bound_box contains 8 corners
            matrix_world = child.matrix_world
            for corner in child.bound_box:
                # Transform local corner to world space
                world_corner = matrix_world @ mathutils.Vector(corner)
                if world_corner.z < global_min_z:
                    global_min_z = world_corner.z

    # Fallback: If no meshes are found, use the bone heads as a safety measure
    if not found_mesh:
        global_min_z = min(
            (urdf_obj.matrix_world @ pb.head).z for pb in urdf_obj.pose.bones
        )

    return global_min_z


@persistent
def retarget_frame(scene):
    """
    Handler function executed on every frame change to synchronize
    the URDF robot rig with the BVH motion capture data.
    """
    settings = scene.bvh_mapping_settings
    if not settings.live_retarget:
        return

    urdf, bvh = scene.urdf_rig_object, scene.smoothed_bvh_rig_object
    if not urdf or not bvh:
        return

    # Initialize a persistent dictionary in the Blender scene to store
    # rotation data across frames. This is essential for smoothing and
    # preventing sudden 180-degree flips.
    if "_bvh_smooth_cache" not in scene:
        scene["_bvh_smooth_cache"] = {}

    smooth_cache = scene["_bvh_smooth_cache"]

    # --- 1. ROOT POSITION & ROTATION PROJECTION ---
    if bvh.pose.bones:
        # --- 1.1 DATA & DELTAS ---
        bvh_root_mat = bvh.matrix_world @ bvh.pose.bones[0].matrix
        current_bvh_pos = bvh_root_mat.to_translation()
        current_bvh_rot = bvh_root_mat.to_quaternion()

        ref_pos = mathutils.Vector(scene.get("ref_root_pos", current_bvh_pos))
        bvh_floor_offset = scene.get("bvh_floor_offset", 0.0)

        # Vertical Movement Delta
        corrected_current_z = current_bvh_pos.z - bvh_floor_offset
        delta_z = (
            corrected_current_z - (ref_pos.z - bvh_floor_offset)
        ) * settings.root_scale

        # --- 1.2 DYNAMIC PIVOT CORRECTION (STICKY + SMOOTHED) ---
        active_bvh_contacts = []
        for f_name in [settings.foot_l_name, settings.foot_r_name]:
            bvh_bone = bvh.pose.bones.get(f_name)
            if bvh_bone:
                foot_world_pos = (bvh.matrix_world @ bvh_bone.matrix).to_translation()
                if (foot_world_pos.z - bvh_floor_offset) <= settings.jump_threshold:
                    active_bvh_contacts.append(f_name)

        last_anchor_name = scene.get("_active_anchor_name", "")
        anchor_bone_name = ""

        # 1. Sticky Selection
        if last_anchor_name in active_bvh_contacts:
            anchor_bone_name = last_anchor_name
            is_hard_switch = False
        elif active_bvh_contacts:
            anchor_bone_name = sorted(active_bvh_contacts)[0]
            is_hard_switch = True
        else:
            anchor_bone_name = ""

        pivot_correction = mathutils.Vector((0, 0, 0))
        rotation_correction = mathutils.Quaternion((1, 0, 0, 0))

        if anchor_bone_name:
            bvh_anchor_bone = bvh.pose.bones.get(anchor_bone_name)
            current_bvh_anchor_mat = bvh.matrix_world @ bvh_anchor_bone.matrix
            current_bvh_anchor_pos = current_bvh_anchor_mat.to_translation()
            current_bvh_anchor_quat = current_bvh_anchor_mat.to_quaternion()
            current_rel_pos = bvh_root_mat.inverted() @ current_bvh_anchor_pos

            if is_hard_switch or last_anchor_name == "":
                # Offset-Transfer (Verhindert Sprung beim Bein-Wechsel)
                scene["_last_bvh_rel_pos"] = current_rel_pos
                scene["_last_bvh_anchor_quat"] = current_bvh_anchor_quat
                # Keine Korrektur im ersten Frame nach Wechsel
                scene["_last_applied_pivot_corr"] = mathutils.Vector((0, 0, 0))
            else:
                # --- A. DRIFT BERECHNEN ---
                last_rel_pos = mathutils.Vector(
                    scene.get("_last_bvh_rel_pos", current_rel_pos)
                )
                raw_drift = (current_rel_pos - last_rel_pos) * settings.root_scale

                # --- B. DÄMPFUNG (TRANSLATION) ---
                # 0.2 bedeutet: 20% neue Bewegung, 80% Trägheit
                smoothing_factor = 0.6
                last_corr = mathutils.Vector(
                    scene.get("_last_applied_pivot_corr", (0, 0, 0))
                )
                pivot_correction = last_corr.lerp(raw_drift, smoothing_factor)
                pivot_correction.z = 0

                # --- C. ROTATION DRIFT ---
                last_anchor_quat = mathutils.Quaternion(
                    scene.get("_last_bvh_anchor_quat", current_bvh_anchor_quat)
                )
                rot_drift = current_bvh_anchor_quat @ last_anchor_quat.inverted()
                rot_drift_quat = mathutils.Euler(
                    (
                        -rot_drift.to_euler().x * 0.5,
                        rot_drift.to_euler().y * 0.5,
                        -rot_drift.to_euler().z,
                    ),
                    "XYZ",
                ).to_quaternion()
                rotation_correction = mathutils.Quaternion((1, 0, 0, 0)).slerp(
                    rot_drift_quat.inverted(), smoothing_factor
                )

            # Speicher-Updates
            scene["_active_anchor_name"] = anchor_bone_name
            scene["_last_bvh_rel_pos"] = current_rel_pos
            scene["_last_bvh_anchor_quat"] = current_bvh_anchor_quat
            scene["_last_applied_pivot_corr"] = pivot_correction
        else:
            scene["_active_anchor_name"] = ""
            scene["_last_applied_pivot_corr"] = mathutils.Vector((0, 0, 0))

        # --- ANWENDUNG AUF URDF ---
        # 1. Rotation anwenden (mit Dämpfung gegen Jitter)
        urdf.rotation_mode = "QUATERNION"
        urdf.rotation_quaternion = rotation_correction @ urdf.rotation_quaternion

        # 2. Position anwenden
        target_loc = (
            mathutils.Vector(
                (
                    (current_bvh_pos.x - ref_pos.x) * settings.root_scale,
                    (current_bvh_pos.y - ref_pos.y) * settings.root_scale,
                    delta_z,
                )
            )
            - pivot_correction
        )

        # Set URDF Root Position with Offset
        offset_xy = settings.location_offset
        loc_offset = mathutils.Vector(
            (offset_xy[0], offset_xy[1], scene.get("urdf_height_offset", 0.0))
        )
        urdf.location = target_loc + loc_offset

        # --- 1.4 ROTATION ---
        ref_rot = mathutils.Quaternion(scene.get("ref_root_rot", current_bvh_rot))
        off_q = mathutils.Euler(settings.rotation_offset).to_quaternion()
        delta_rot = (current_bvh_rot @ ref_rot.inverted()).inverted()
        delta_rot.x *= -1
        delta_rot.z *= -1
        urdf.rotation_mode = "QUATERNION"
        urdf.rotation_quaternion = off_q @ delta_rot

    # --- 3. JOINT RETARGETING LOOP ---
    # Iterate through all bone mappings defined in the UI list
    for item in settings.mappings:
        bvh_b = bvh.pose.bones.get(item.bvh_bone_name)
        if not bvh_b:
            continue

        # REFERENCE TRANSFORMATION:
        # Calculate the rotation 'delta' relative to the saved reference pose (T-Pose).
        # This isolates the actual movement performed during the animation.
        ref_q = mathutils.Quaternion(item.ref_rot)
        current_q = bvh_b.matrix_basis.to_quaternion()
        delta_q = ref_q.inverted() @ current_q

        # --- 3. TRANSFORMATION & EXTRAKTION ---
        # A single BVH bone might drive multiple URDF joints (e.g., Shoulder X and Y)
        for b in item.urdf_bones:
            urdf_b = urdf.pose.bones.get(b.urdf_bone_name)
            if not urdf_b:
                continue

            # JOINT TYPE AWARENESS:
            # Handle different logic for revolute (rotation) vs prismatic (translation) joints
            jtype = urdf_b.get("joint_type", "revolute")

            # Only revolute and continuous joints are supported in this retargeting engine
            if jtype not in {"revolute", "continuous"}:
                continue

            # ROTATION PROJECTION:
            # 1. Define the twist axis in BVH local space
            if b.source_axis == "X":
                twist_axis = mathutils.Vector((1, 0, 0))
            elif b.source_axis == "Y":
                twist_axis = mathutils.Vector((0, 1, 0))
            else:
                twist_axis = mathutils.Vector((0, 0, 1))

            # 2. Extract the component of rotation around the twist axis
            # Project the quaternion vector part onto the twist axis
            q_vec = mathutils.Vector((delta_q.x, delta_q.y, delta_q.z))
            projection = q_vec.dot(twist_axis)

            # 3. Calculate the angle around the twist axis
            # Use the atan2 formulation for better numerical stability
            val = 2.0 * math.atan2(projection, delta_q.w)

            # CONTINUITY CHECK (Anti-Flip) only for revolute/continuous joints:
            # Rotations often jump from +180 to -180 degrees (Pi to -Pi).
            # We track the value over time and add/subtract 2*Pi to keep the motion continuous.
            if jtype in ("revolute", "continuous"):
                cache_val_key = f"val_{bvh.name}_{b.urdf_bone_name}"
                if cache_val_key in smooth_cache:
                    prev_val = smooth_cache[cache_val_key]
                    diff = val - prev_val
                    if diff > math.pi:
                        val -= 2 * math.pi
                    elif diff < -math.pi:
                        val += 2 * math.pi
                smooth_cache[cache_val_key] = val

            # VELOCITY LIMITING (Rate-Limiting with Damping):
            # Ensure movement does not exceed the hardware velocity limits.
            velocity_limit = urdf_b.get("velocity_limit", 10.0)  # Default 10 rad/s
            last_raw_key = f"last_raw_{bvh.name}_{b.urdf_bone_name}"
            last_raw_val = smooth_cache.get(last_raw_key, val)

            # Calculate raw velocity
            raw_diff = val - last_raw_val
            # Re-apply anti-flip correction
            if jtype in ("revolute", "continuous"):
                if raw_diff > math.pi:
                    raw_diff -= 2 * math.pi
                elif raw_diff < -math.pi:
                    raw_diff += 2 * math.pi

            target_hz = scene.render.fps if scene.render.fps > 0 else 60.0
            dt = 1.0 / target_hz
            current_velocity = abs(raw_diff) / dt

            if current_velocity > velocity_limit and velocity_limit > 0.0:
                # Apply damping: cap the step size to the maximum allowed velocity
                max_step = velocity_limit * dt
                safe_diff = max_step if raw_diff > 0 else -max_step
                val = last_raw_val + safe_diff
                urdf_b["is_velocity_limited"] = True
            else:
                urdf_b["is_velocity_limited"] = False

            smooth_cache[last_raw_key] = val

            # Adjust sign and apply the zero-offset (calibration offset)
            if b.sign == "NEG":
                val = -val
            if "offset" not in urdf_b:
                urdf_b["offset"] = val

            # Combine the relative movement with the robot's mechanical neutral position
            target_angle = val - urdf_b["offset"] + b.neutral_offset

            # OUTPUT SMOOTHING (Exponential Moving Average):
            # Final filter to simulate motor inertia and create clean training data.
            if "_last_urdf_angle" not in urdf_b:
                urdf_b["_last_urdf_angle"] = target_angle

            # Alpha determines the "stiffness" of the joint.
            # (1.0 = direct response, 0.1 = very soft/delayed)
            alpha_joint = 1.0 - settings.joint_smoothing
            final_angle = (alpha_joint * target_angle) + (
                (1.0 - alpha_joint) * urdf_b["_last_urdf_angle"]
            )
            urdf_b["_last_urdf_angle"] = final_angle

            # JOINT LIMITS:
            # Ensure the angle does not exceed the mechanical limits defined in the URDF.
            if jtype != "continuous":
                l_min = urdf_b.get("limit_lower", -3.14)
                l_max = urdf_b.get("limit_upper", 3.14)
                final_angle = max(min(final_angle, l_max), l_min)

            # Store the computed angle for external export scripts
            urdf_b["_joint_angle"] = final_angle

            # APPLICATION:
            # Apply the rotation to the Blender Bone.
            # Note: We use a local Y-axis rotation as the standard for robot joints.
            urdf_b.rotation_mode = "QUATERNION"
            urdf_b.rotation_quaternion = mathutils.Quaternion((0, 1, 0), final_angle)

    # --- 4. DYNAMIC FOOT ALIGNMENT ---
    # Ziel: Füße in Bodennähe parallel ausrichten, um 'Toe-Digging' beim Export zu verhindern.
    # 1. Update der Szenen-Matrizen, da wir oben gerade Bones rotiert haben
    bpy.context.view_layer.update()

    flatten_str = settings.foot_flattening_strength
    flatten_height = settings.foot_flattening_height
    floor_z = 0.0

    if flatten_str > 0.001:
        # 2. Lookup-Map erstellen: Welcher BVH-Bone steuert welche URDF-Bones?
        # Wir brauchen das, weil settings.foot_l/r_name nur den BVH-Namen kennt.
        bvh_to_urdf_map = {}
        for item in settings.mappings:
            if item.bvh_bone_name in [settings.foot_l_name, settings.foot_r_name]:
                # Wir sammeln alle URDF Bones, die an diesem BVH Bone hängen
                urdf_names = [b.urdf_bone_name for b in item.urdf_bones]
                bvh_to_urdf_map[item.bvh_bone_name] = urdf_names

        # 3. Iteration über beide Füße (Links und Rechts)
        for bvh_foot_name in [settings.foot_l_name, settings.foot_r_name]:

            # Haben wir URDF Bones für diesen Fuß gefunden?
            if bvh_foot_name not in bvh_to_urdf_map:
                continue

            for bvh_foot_name in [settings.foot_l_name, settings.foot_r_name]:
                if bvh_foot_name not in bvh_to_urdf_map:
                    continue

                # Wir iterieren über alle URDF-Knochen, die diesem Fuß zugeordnet sind.
                # (Meistens ist das der 'Ankle_Pitch' oder ähnlich)
                for u_name in bvh_to_urdf_map[bvh_foot_name]:
                    urdf_b = urdf.pose.bones.get(u_name)
                    if not urdf_b:
                        continue

                    # JOINT TYPE AWARENESS:
                    # Handle different logic for revolute (rotation) vs prismatic (translation) joints
                    jtype = urdf_b.get("joint_type", "revolute")

                    # Only revolute and continuous joints are supported in this retargeting engine
                    if jtype not in {"revolute", "continuous"}:
                        continue

                    # A. Aktuelle Welt-Transformation und Höhe prüfen
                    # Wir nehmen den Tail des Bones, da dieser oft die Sohle repräsentiert,
                    # oder Head, je nach Rigging. Hier nehmen wir die Translation der Matrix (Head).
                    foot_mat_world = urdf.matrix_world @ urdf_b.matrix
                    foot_pos = foot_mat_world.to_translation()

                    # Distanz zum Boden
                    dist_to_floor = foot_pos.z - floor_z

                    # B. Nur eingreifen, wenn wir nah am Boden sind
                    if dist_to_floor < flatten_height:

                        # C. Blend-Faktor berechnen (Linear)
                        ratio = 1.0 - (dist_to_floor / flatten_height)
                        influence = max(0.0, min(1.0, ratio)) * flatten_str

                        if influence <= 0.001:
                            continue

                        # D. Ziel-Berechnung: "Wie müsste ich stehen, um flach zu sein?"
                        # 1. Aktuelle Orientierung
                        current_world_quat = foot_mat_world.to_quaternion()

                        # 2. Wunsch-Orientierung (Welt):
                        # Pitch/Roll genullt (parallel zu XY), Yaw (Z) beibehalten.
                        current_world_euler = current_world_quat.to_euler("XYZ")
                        flat_world_quat = mathutils.Euler(
                            (0, 0, current_world_euler.z), "XYZ"
                        ).to_quaternion()

                        # 4. Differenz in den LOKALEN Raum des Knochens transformieren
                        # Wir projizieren die Welt-Differenz auf das lokale Koordinatensystem des Bones.
                        # Da Rotationen sich addieren, ist die lokale Differenz ungefähr gleich der Welt-Differenz,
                        # aber wir müssen die Achsen beachten.
                        # Einfacherer Weg: Wir rechnen alles in Local Space um.

                        if urdf_b.parent:
                            parent_world = urdf.matrix_world @ urdf_b.parent.matrix
                            # Inverse Parent * Target World = Target Local
                            target_local_mat = (
                                parent_world.inverted()
                                @ flat_world_quat.to_matrix().to_4x4()
                            )
                            target_local_quat = target_local_mat.to_quaternion()
                        else:
                            target_local_quat = (
                                urdf.matrix_world.inverted()
                                @ flat_world_quat.to_matrix().to_4x4()
                            ).to_quaternion()

                        # Aktuelle lokale Rotation
                        current_local_quat = urdf_b.rotation_quaternion

                        # Die nötige relative Rotation von Local -> Target Local
                        rel_quat = current_local_quat.inverted() @ target_local_quat

                        # E. CONSTRAINT: Nur Y-Achse verwenden!
                        # Wir zerlegen die relative Rotation in Euler-Winkel.
                        # Da wir im Local Space sind, entspricht rel_euler.y genau der Drehung um die Knochen-Achse.
                        rel_euler = rel_quat.to_euler("XYZ")

                        # Wir ignorieren x und z (Pitch/Roll constraints des Gelenks)
                        # Wir nehmen nur y (Revolute Joint Axis)
                        delta_y = rel_euler.y * influence

                        current_angle = urdf_b["_joint_angle"]
                        final_angle = current_angle + delta_y
                        # JOINT LIMITS:
                        # Ensure the angle does not exceed the mechanical limits defined in the URDF.
                        if jtype != "continuous":
                            l_min = urdf_b.get("limit_lower", -3.14)
                            l_max = urdf_b.get("limit_upper", 3.14)
                            final_angle = max(min(final_angle, l_max), l_min)

                        urdf_b.rotation_mode = "QUATERNION"
                        urdf_b.rotation_quaternion = mathutils.Quaternion(
                            (0, 1, 0), final_angle
                        )
                        urdf_b["_joint_angle"] = final_angle

        # --- 5. ANTI-SINKING CHECK (Globales Grounding) ---
        bpy.context.view_layer.update()  # Important: Blender needs to update matrices

        current_min_z = get_lowest_z_world(urdf)
        if current_min_z < -1e-4:  # Allow a tiny epsilon for numerical stability
            urdf.location.z += abs(current_min_z)


# ============================================================
# EXPORT OPERATOR (DIR Selection + Dual File Output)
# ============================================================


class OT_ExportBeyondMimic(Operator):
    """Exports both CSV trajectory and JSON metadata with time-based resampling."""

    bl_idname = "object.export_beyond_mimic"
    bl_label = "Export CSV & JSON"
    bl_description = "Select directory; files will be named after the Source BVH rig and resampled to Target Hz"

    directory: StringProperty(name="Export Directory", subtype="DIR_PATH")

    # Internal Modal State
    _timer = None
    _num_steps = 0
    _current_step = 0
    _time_per_step = 0
    _duration = 0
    _total_frames = 0
    _data_rows = []
    _meta_joints = {}
    _csv_path = ""
    _json_path = ""
    _orig_frame = 0
    _joints = []
    _base_name = ""

    def modal(self, context, event):
        scene = context.scene
        urdf = scene.urdf_rig_object
        fps = scene.render.fps

        if event.type == "ESC":
            return self.cancel(context)

        if event.type == "TIMER":
            if self._current_step < self._num_steps:
                # Calculate current time in seconds
                current_time_secs = self._current_step * self._time_per_step

                # Map time back to Blender frames (including subframes for precision)
                blender_frame = scene.frame_start + (current_time_secs * fps)

                # Set frame and subframe (crucial for smooth interpolation)
                scene.frame_set(int(blender_frame), subframe=blender_frame % 1.0)

                # Collect Root Data
                row = [
                    urdf.location.x,
                    urdf.location.y,
                    urdf.location.z,
                    urdf.rotation_quaternion.x,
                    urdf.rotation_quaternion.y,
                    urdf.rotation_quaternion.z,
                    urdf.rotation_quaternion.w,
                ]

                # Collect Joint Data
                for j in self._joints:
                    pb = urdf.pose.bones[j]
                    row.append(pb.get("_joint_angle", 0.0))
                    if self._current_step == 0:
                        # Metadata (limits) only needed once
                        self._meta_joints[j] = {
                            "lower": pb.get("limit_lower", -3.14),
                            "upper": pb.get("limit_upper", 3.14),
                        }

                self._data_rows.append(row)

                # UI Update
                context.workspace.status_text_set(
                    f"Export Beyond Mimic: Step {self._current_step}/{self._num_steps} | ESC to Cancel"
                )
                context.window_manager.progress_update(self._current_step)

                self._current_step += 1
            else:
                return self.finish(context)

        return {"RUNNING_MODAL"}

    def execute(self, context):
        scene = context.scene
        settings = scene.bvh_mapping_settings
        urdf, bvh = scene.urdf_rig_object, scene.bvh_rig_object

        if not urdf or not bvh or not self.directory:
            self.report({"ERROR"}, "Robot, BVH Rig or Directory missing!")
            return {"CANCELLED"}

        # Initialize Paths
        self._base_name = bpy.path.clean_name(bvh.name)
        self._csv_path = os.path.join(self.directory, f"{self._base_name}.csv")
        self._json_path = os.path.join(self.directory, f"{self._base_name}_meta.json")

        # Resampling Setup
        fps = scene.render.fps
        self._total_frames = scene.frame_end - scene.frame_start
        self._duration = self._total_frames / fps
        target_hz = settings.target_hz
        self._num_steps = int(self._duration * target_hz) + 1
        self._time_per_step = 1.0 / target_hz

        self._joints = list(urdf.get("urdf_joint_order", []))
        self._current_step = 0
        self._data_rows = []
        self._meta_joints = {}
        self._orig_frame = scene.frame_current

        # Modal Setup
        wm = context.window_manager
        wm.progress_begin(0, self._num_steps)
        self._timer = wm.event_timer_add(0.001, window=context.window)
        wm.modal_handler_add(self)

        return {"RUNNING_MODAL"}

    def finish(self, context):
        scene = context.scene
        settings = scene.bvh_mapping_settings
        urdf = scene.urdf_rig_object

        # Create CSV Header
        header = [
            "root_tx",
            "root_ty",
            "root_tz",
            "root_qx",
            "root_qy",
            "root_qz",
            "root_qw",
        ] + self._joints

        # Write CSV and JSON Files
        try:
            with open(self._csv_path, "w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(header)
                writer.writerows(self._data_rows)

            with open(self._json_path, "w") as f:
                json.dump(
                    {
                        # Origin Info
                        "source_bvh": self._base_name,
                        "target_urdf": bpy.path.clean_name(urdf.name),
                        # Timing
                        "source_fps": scene.render.fps,
                        "source_total_frames": self._total_frames,
                        "export_hz": settings.target_hz,
                        "duration_secs": self._duration,
                        "total_samples": len(self._data_rows),
                        # Export Settings
                        "bvh_smoothing": settings.bvh_smoothing,
                        "joint_smoothing": settings.joint_smoothing,
                        # Units
                        "measurement_unit": "meters",
                        "angle_unit": "radians",
                        # Root / Base definition
                        "root": {
                            "type": "free_floating_base",
                            "frame": "blender_world",
                            "dofs": ["x", "y", "z", "qx", "qy", "qz", "qw"],
                            "representation": "quaternion",
                            "note": "No semantic root bone; base pose is encoded as world-space transform of the URDF armature object",
                        },
                        # Coordinate system (explicit but honest)
                        "coordinate_system": {
                            "space": "blender_world",
                            "up_axis": "Z",
                            "forward_axis": None,
                            "right_axis": "X",
                            "note": "URDF does not define a semantic forward axis; heading is encoded in the root orientation quaternion",
                        },
                        # Joint definition
                        "joints": {
                            "order": self._joints,
                            "type": "hinge",
                            "angle_unit": "radians",
                            "limits": self._meta_joints,
                        },
                    },
                    f,
                    indent=4,
                )

            self.report(
                {"INFO"},
                f"Export finished: {self._base_name}.csv; {self._base_name}_meta.json",
            )
        except Exception as e:
            self.report({"ERROR"}, f"File Error: {str(e)}")

        self.cleanup(context)
        return {"FINISHED"}

    def cancel(self, context):
        self.cleanup(context)
        self.report({"WARNING"}, "Export cancelled")
        return {"CANCELLED"}

    def cleanup(self, context):
        context.scene.frame_set(self._orig_frame)
        context.window_manager.event_timer_remove(self._timer)
        context.window_manager.progress_end()
        context.workspace.status_text_set(None)
        bpy.ops.object.apply_bvh_mapping()  # Final retarget to restore state

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        bpy.ops.object.apply_bvh_mapping()  # Ensure final retarget before export
        return {"RUNNING_MODAL"}


# ============================================================
# UI IMPLEMENTATION
# ============================================================


class UL_BVHMappingList(UIList):
    def draw_item(
        self, context, layout, data, item, icon, active_data, active_propname, index
    ):
        row = layout.row(align=True)
        row.label(text=f"BVH: {item.bvh_bone_name}")
        count = len(item.urdf_bones)
        if count > 0:
            row.label(text=f"URDF: {count}")
        else:
            row.enabled = False
            row.label(text=f"URDF: {count}")


class UL_URDFBoneList(UIList):
    def draw_item(
        self, context, layout, data, item, icon, active_data, active_propname, index
    ):
        urdf_obj = context.scene.urdf_rig_object
        row = layout.row(align=True)

        # Check if the current URDF bone has reached its velocity limit
        if urdf_obj and item.urdf_bone_name in urdf_obj.pose.bones:
            ub = urdf_obj.pose.bones[item.urdf_bone_name]
            if ub.get("is_velocity_limited"):
                row.label(text="", icon="ERROR")
                row.alert = True  # Colors the property field red

        if urdf_obj:
            row.prop_search(
                item,
                "urdf_bone_name",
                urdf_obj.pose,
                "bones",
                text="",
            )

        row.prop(item, "source_axis", text="")
        row.prop(item, "sign", text="")
        row.prop(item, "neutral_offset", text="")


class PANEL_BVHMapping(Panel):
    bl_label = "URDF Robot Retargeting"
    bl_idname = "VIEW3D_PT_urdf_mapping"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "BVH → URDF Retargeting"

    def check_duplicate_mappings(self, context):
        settings = context.scene.bvh_mapping_settings
        used_urdf_bones = {}
        duplicates = []

        for item in settings.mappings:
            for u_bone in item.urdf_bones:
                name = u_bone.urdf_bone_name  # URDF joint name
                if name:
                    if name in used_urdf_bones:
                        used_urdf_bones[name].append(item.bvh_bone_name)
                        if name not in duplicates:
                            duplicates.append(name)
                    else:
                        used_urdf_bones[name] = [item.bvh_bone_name]

        return duplicates, used_urdf_bones

    def draw(self, context):
        layout = self.layout
        s = context.scene
        settings = s.bvh_mapping_settings
        layout.prop(s, "urdf_rig_object")
        layout.prop(s, "bvh_rig_object")

        box = layout.box()
        box.label(text="BVH → URDF Options")
        box.prop(settings, "root_scale")
        box.prop(settings, "location_offset")
        box.prop(settings, "rotation_offset")
        box.prop_search(
            settings,
            "foot_l_name",
            context.scene.bvh_rig_object.pose,
            "bones",
            text="Left Foot",
        )
        box.prop_search(
            settings,
            "foot_r_name",
            context.scene.bvh_rig_object.pose,
            "bones",
            text="Right Foot",
        )
        box.prop(settings, "jump_threshold")
        box.prop(settings, "foot_flattening_height")
        box.prop(settings, "foot_flattening_strength")
        box.prop(settings, "bvh_smoothing")
        box.prop(settings, "joint_smoothing")

        layout.operator("object.generate_mapping_list")
        if not settings.mappings:
            layout.label(
                text="Click 'Generate Mapping List' to show bones.", icon="INFO"
            )
            return
        else:
            layout.template_list(
                "UL_BVHMappingList",
                "",
                settings,
                "mappings",
                settings,
                "active_mapping_index",
            )
            if 0 <= settings.active_mapping_index < len(settings.mappings):
                active = settings.mappings[settings.active_mapping_index]
                box = layout.box()
                row = box.row()
                row.template_list(
                    "UL_URDFBoneList",
                    "",
                    active,
                    "urdf_bones",
                    settings,
                    "active_urdf_index",
                )
                col = row.column(align=True)
                col.operator(
                    "object.add_urdf_bone", text="", icon="ADD"
                ).bvh_bone_name = active.bvh_bone_name
                col.operator(
                    "object.remove_urdf_bone", text="", icon="REMOVE"
                ).bvh_bone_name = active.bvh_bone_name
        duplicates, _ = self.check_duplicate_mappings(context)
        if duplicates:
            box = layout.box()
            box.alert = True  # Highlight box in red
            col = box.column()
            col.label(text="WARNING: Multiple assignments!", icon="ERROR")
            for d in duplicates:
                col.label(
                    text=f"Joint '{d}' is controlled multiple times", icon="BONE_DATA"
                )
        layout.operator("object.apply_bvh_mapping")

        layout.separator()
        box = layout.box()
        box.label(text="Export Beyond Mimic", icon="EXPORT")
        box.prop(settings, "target_hz")
        box.operator("object.export_beyond_mimic", text="Export")


# ============================================================
# OPERATORS & REGISTRATION
# ============================================================


class OT_GenerateMappingList(Operator):
    bl_idname = "object.generate_mapping_list"
    bl_label = "Generate Mapping List"
    bl_description = "Generates BVH bone list from selected BVH rig"

    def execute(self, context):
        scene = context.scene
        settings = scene.bvh_mapping_settings
        bvh_rig = scene.bvh_rig_object
        if not bvh_rig:
            return {"CANCELLED"}

        settings.mappings.clear()
        for ub in [pb.name for pb in bvh_rig.pose.bones]:
            item = settings.mappings.add()
            item.bvh_bone_name = ub

        settings.active_mapping_index = 0
        settings.active_urdf_index = 0
        return {"FINISHED"}


class OT_ApplyBVHMapping(Operator):
    """Resets the URDF rig to default pose, moves to frame 0, and initializes retargeting"""

    bl_idname = "object.apply_bvh_mapping"
    bl_label = "Apply Mapping"
    bl_description = "Resets rig to neutral pose at frame 0 and starts live retargeting"

    def check_bvh_rotation_mode(self, bvh_obj):
        """Checks if all bones in the BVH armature use QUATERNION rotation mode."""
        if bvh_obj.type != "ARMATURE":
            return False

        # Check each bone's rotation mode
        for pbone in bvh_obj.pose.bones:
            if pbone.rotation_mode != "QUATERNION":
                return False
        return True

    def apply_zero_lag_smoothing(self, context, bvh_obj, smoothing_factor):
        """Creates a copie of the BVH object and applies Zero-Lag Smoothing it's F-Curves."""
        # 1. Remove existing smoothed object if present
        smoothed_name = f"{bvh_obj.name}_smoothed"
        if smoothed_name in bpy.data.objects:
            bvh_obj.hide_viewport = False
            context.view_layer.objects.active = bvh_obj
            bpy.data.objects.remove(bpy.data.objects[smoothed_name], do_unlink=True)

        # 2. Create a copy of the BVH object to apply smoothing
        new_obj = bvh_obj.copy()
        new_obj.data = bvh_obj.data.copy()
        new_obj.name = smoothed_name
        if bvh_obj.animation_data and bvh_obj.animation_data.action:
            new_obj.animation_data.action = bvh_obj.animation_data.action.copy()

        context.collection.objects.link(new_obj)

        # Hide original BVH object from viewport and set new as active
        bvh_obj.hide_viewport = True
        context.view_layer.objects.active = new_obj

        # 3. Set bone rotation modes to QUATERNION for consistency
        bpy.ops.object.mode_set(mode="POSE")
        for pbone in new_obj.pose.bones:
            pbone.rotation_mode = "QUATERNION"
        bpy.ops.object.mode_set(mode="OBJECT")

        action = new_obj.animation_data.action
        slot = new_obj.animation_data.action_slot
        channelbag = action_get_channelbag_for_slot(action, slot)
        if not channelbag:
            return new_obj

        # 4. Group F-Curves by Data Path
        # Example: "pose.bones["Root"].location" or "...rotation_quaternion"
        curves_by_group = {}
        for fc in channelbag.fcurves:
            key = fc.data_path
            if key not in curves_by_group:
                curves_by_group[key] = []
            curves_by_group[key].append(fc)

        # 5. Apply Zero-Lag Smoothing
        alpha = 1.0 - smoothing_factor
        for path, curves in curves_by_group.items():
            curves.sort(key=lambda x: x.array_index)
            num_keys = len(curves[0].keyframe_points)
            if num_keys < 2:
                continue

            is_quat = "rotation_quaternion" in path
            is_loc = "location" in path

            # Only process Quaternion rotations or Location vectors
            if not (is_quat or is_loc):
                continue

            # Load keyframe data into arrays
            all_data = []
            for fc in curves:
                coords = [0.0] * (num_keys * 2)
                fc.keyframe_points.foreach_get("co", coords)
                all_data.append(coords)

            # Convert keyframe data to mathutils types
            points = []
            for i in range(num_keys):
                idx = i * 2 + 1
                if is_quat and len(curves) == 4:
                    points.append(
                        mathutils.Quaternion(
                            (
                                all_data[0][idx],
                                all_data[1][idx],
                                all_data[2][idx],
                                all_data[3][idx],
                            )
                        )
                    )
                else:  # Location (3D Vector)
                    points.append(
                        mathutils.Vector(
                            (all_data[0][idx], all_data[1][idx], all_data[2][idx])
                        )
                    )

            # --- Core Zero-Lag Smoothing ---
            smoothed = [p.copy() for p in points]

            # Forward Pass
            for i in range(1, num_keys):
                if is_quat:
                    smoothed[i] = smoothed[i - 1].slerp(points[i], alpha)
                else:
                    smoothed[i] = smoothed[i - 1].lerp(points[i], alpha)

            # Backward Pass (Zero-Lag)
            for i in range(num_keys - 2, -1, -1):
                if is_quat:
                    smoothed[i] = smoothed[i + 1].slerp(smoothed[i], alpha)
                else:
                    smoothed[i] = smoothed[i + 1].lerp(smoothed[i], alpha)

            # Write back smoothed data
            for i, fc in enumerate(curves):
                for k in range(num_keys):
                    all_data[i][k * 2 + 1] = smoothed[k][i]
                fc.keyframe_points.foreach_set("co", all_data[i])
                fc.update()

        return new_obj

    def execute(self, context):
        scene = context.scene
        settings = scene.bvh_mapping_settings
        bvh_obj = scene.bvh_rig_object
        urdf_obj = scene.urdf_rig_object

        # 1. Reset timeline to start
        scene.frame_set(0)

        if urdf_obj:
            # 2. Reset all pose bones to neutral URDF orientation
            for pb in urdf_obj.pose.bones:
                # Reset rotation and respect joint limits (assuming Quaternion mode as used in retarget_frame)
                pb.rotation_mode = "QUATERNION"

                l_min = pb.get("limit_lower", -3.14)
                l_max = pb.get("limit_upper", 3.14)
                neutral = max(min(0.0, l_max), l_min)

                pb.rotation_quaternion = mathutils.Quaternion((0, 1, 0), neutral)

                # 3. Clear internal calculation caches for this bone
                for key in ("offset", "_joint_angle", "_last_urdf_angle"):
                    if key in pb:
                        del pb[key]

        # 4. Clear global smoothing caches from the scene
        if "_bvh_smooth_cache" in scene:
            # We clear the dictionary content rather than popping the key
            # to avoid iteration errors if the handler is currently running
            scene["_bvh_smooth_cache"] = {}
        if "_last_urdf_pivot" in scene:
            scene["_last_urdf_pivot"] = None

        # 5. Enable the retargeting handler
        # and set current BVH pose as reference
        scene.bvh_mapping_settings.live_retarget = (
            False  # Temporarily disable to avoid interference
        )
        if settings.bvh_smoothing > 0.0:
            if not self.check_bvh_rotation_mode(bvh_obj):
                self.report(
                    {"ERROR"},
                    "Smoothing requires BVH-Rig to be imported with Quaternion rotations!",
                )
                return {"CANCELLED"}

            self.report(
                {"INFO"},
                f"Zero-Lag Smoothing BVH Animation (Factor: {settings.bvh_smoothing})...",
            )
            scene.smoothed_bvh_rig_object = self.apply_zero_lag_smoothing(
                context, bvh_obj, settings.bvh_smoothing
            )
        else:
            scene.smoothed_bvh_rig_object = bvh_obj
        bpy.ops.object.calibrate_rest_pose()  # Sets reference pose on smmoothed BVH
        scene.bvh_mapping_settings.live_retarget = True

        # 6. Burn in frame 0 to ensure all calculations are up to date
        for _ in range(100):
            scene.frame_set(0)
            context.view_layer.update()

        self.report({"INFO"}, "Rig reset to frame 0. Retargeting active.")
        return {"FINISHED"}


class OT_AddBVHBone(Operator):
    bl_idname = "object.add_urdf_bone"
    bl_label = "Add"
    bl_description = "Add URDF Bone to Mapping"
    bvh_bone_name: StringProperty()

    def execute(self, context):
        m = next(
            i
            for i in context.scene.bvh_mapping_settings.mappings
            if i.bvh_bone_name == self.bvh_bone_name
        )
        m.urdf_bones.add()
        return {"FINISHED"}


class OT_RemoveBVHBone(Operator):
    bl_idname = "object.remove_urdf_bone"
    bl_label = "Rem"
    bl_description = "Remove URDF Bone from Mapping"
    bvh_bone_name: StringProperty()

    def execute(self, context):
        m = next(
            i
            for i in context.scene.bvh_mapping_settings.mappings
            if i.bvh_bone_name == self.bvh_bone_name
        )
        m.urdf_bones.remove(context.scene.bvh_mapping_settings.active_urdf_index)
        return {"FINISHED"}


class OT_CalibrateRestPose(Operator):
    """Calibrates the mapping offsets based on the current BVH Pose"""

    bl_idname = "object.calibrate_rest_pose"
    bl_label = "Calibrate Rest Pose"
    bl_description = "Saves the current BVH rotation as the neutral reference."

    def execute(self, context):
        scene = context.scene
        settings = context.scene.bvh_mapping_settings
        bvh = context.scene.smoothed_bvh_rig_object
        urdf = context.scene.urdf_rig_object

        if not bvh:
            self.report({"ERROR"}, "No BVH Rig selected!")
            return {"CANCELLED"}
        if not urdf:
            self.report({"ERROR"}, "No URDF Rig selected!")
            return {"CANCELLED"}

        # Store the current BVH root position and rotation as reference
        bvh_root_mat = bvh.matrix_world @ bvh.pose.bones[0].matrix
        scene["ref_root_pos"] = bvh_root_mat.to_translation().copy()
        scene["ref_root_rot"] = bvh_root_mat.to_quaternion().copy()

        count = 0
        # Iterate through all mapping items and store the current BVH bone rotation as reference
        for item in settings.mappings:
            bvh_bone = bvh.pose.bones.get(item.bvh_bone_name)
            if bvh_bone:
                # Store the current rotation as reference
                item.ref_rot = bvh_bone.matrix_basis.to_quaternion()
                count += 1

        if (
            settings.foot_l_name in bvh.pose.bones
            and settings.foot_r_name in bvh.pose.bones
        ):
            lowest_bvh_z = min(
                (bvh.matrix_world @ bvh.pose.bones.get(settings.foot_l_name).matrix)
                .to_translation()
                .z,
                (bvh.matrix_world @ bvh.pose.bones.get(settings.foot_r_name).matrix)
                .to_translation()
                .z,
            )
            if scene.get("bvh_floor_offset", None) is None:
                scene["bvh_floor_offset"] = lowest_bvh_z

            if scene.get("urdf_height_offset", None) is None:
                scene["urdf_height_offset"] = abs(get_lowest_z_world(urdf))

        self.report({"INFO"}, f"Calibrated {count} bones. Reference set.")
        return {"FINISHED"}


class IMPORT_OT_urdf_humanoid(Operator, ImportHelper):
    bl_idname = "import_scene.urdf_humanoid"
    bl_label = "Import URDF"
    bl_description = (
        "Imports a URDF humanoid robot and creates an armature with bound meshes."
    )
    filename_ext = ".urdf"

    def execute(self, context):
        robot = parse_urdf(self.filepath)
        arm, link_mats = create_urdf_armature(robot)
        bind_meshes(robot, arm, link_mats, os.path.dirname(self.filepath))

        context.scene.urdf_rig_object = arm

        # We only want movable joints for the trajectory (Beyond Mimic requirement)
        arm["urdf_joint_order"] = [
            j.name
            for j in robot.joints.values()
            if j.type in {"revolute", "continuous", "prismatic"}
        ]

        return {"FINISHED"}


def menu_func_import(self, context):
    self.layout.operator(
        IMPORT_OT_urdf_humanoid.bl_idname, text="URDF Humanoid (.urdf)"
    )


classes = [
    BVHMappingBone,
    BVHMappingItem,
    BVHMappingSettings,
    UL_BVHMappingList,
    UL_URDFBoneList,
    PANEL_BVHMapping,
    OT_GenerateMappingList,
    OT_ApplyBVHMapping,
    OT_CalibrateRestPose,
    OT_AddBVHBone,
    OT_RemoveBVHBone,
    OT_ExportBeyondMimic,
    IMPORT_OT_urdf_humanoid,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.bvh_mapping_settings = PointerProperty(type=BVHMappingSettings)
    bpy.types.Scene.urdf_rig_object = PointerProperty(type=bpy.types.Object)
    bpy.types.Scene.bvh_rig_object = PointerProperty(type=bpy.types.Object)
    bpy.types.Scene.smoothed_bvh_rig_object = PointerProperty(type=bpy.types.Object)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.app.handlers.frame_change_post.append(retarget_frame)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    bpy.app.handlers.frame_change_post.remove(retarget_frame)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
